
;;; ===========================================================================
;;; STEP5_Tools.lsp   (CASS10 / AutoCAD 2016)   V1.2
;;; �� STEP5_Run_V1.2.ps1 ���õĹ��ߺ���
;;;   (c:S5MARK)                ���ñ����� *S5-MARK*
;;;   (c:S5MOVETOP ltx lty)     ���ƶ����֮���½���ʵ�壬ʹ���Χ�����ϽǶ��� (ltx,lty)
;;;   (c:S5MOVELB lbx lby)      ͬ�ϣ��������½�
;;;   (c:S5NEWBB)               ��ӡ���֮���½�ʵ��İ�Χ��
;;;   (c:S5PICKAT x y)          ���ص� (x,y) ��ʰȡ����ʵ������д�� *S5-PICKFILE*��
;;; ===========================================================================

(defun s5:entbb (e / obj mn mx a b)
  (setq obj (vlax-ename->vla-object e))
  (vla-getboundingbox obj 'mn 'mx)
  (setq a (vlax-safearray->list mn)
        b (vlax-safearray->list mx))
  (list (car a) (cadr a) (car b) (cadr b))
)

(defun s5:newset ( / ss e)
  (setq ss (ssadd))
  (if *S5-MARK*
    (progn
      (setq e (entnext *S5-MARK*))
      (while e (ssadd e ss) (setq e (entnext e)))
    )
  )
  ss
)

(defun s5:newbb ( / ss bb i mnx mny mxx mxy)
  (setq ss (s5:newset))
  (if (= (sslength ss) 0) nil
    (progn
      (setq i 0 mnx nil mny nil mxx nil mxy nil)
      (repeat (sslength ss)
        (setq bb (s5:entbb (ssname ss i)))
        (if bb
          (progn
            (if (or (null mnx) (< (car bb) mnx)) (setq mnx (car bb)))
            (if (or (null mny) (< (cadr bb) mny)) (setq mny (cadr bb)))
            (if (or (null mxx) (> (caddr bb) mxx)) (setq mxx (caddr bb)))
            (if (or (null mxy) (> (cadddr bb) mxy)) (setq mxy (cadddr bb)))
          )
        )
        (setq i (1+ i))
      )
      (list mnx mny mxx mxy)
    )
  )
)

(defun s5:move-new (tx ty mode / ss bb n dx dy)
  (cond
    ((null *S5-MARK*) (princ "\n[STEP5] *S5-MARK* not set"))
    (T
      (setq ss (s5:newset))
      (setq n (sslength ss))
      (if (= n 0)
        (princ "\n[STEP5] no new entity after mark")
        (progn
          (setq bb (s5:newbb))
          (if bb
            (progn
              (if (= mode "TOP")
                (setq dx (- tx (car bb)) dy (- ty (cadddr bb)))
                (setq dx (- tx (car bb)) dy (- ty (cadr bb)))
              )
              (command "_.MOVE" ss "" (list 0.0 0.0) (list dx dy))
              (princ (strcat "\n[STEP5] moved " (itoa n) " new entities dx=" (rtos dx 2 4)
                             " dy=" (rtos dy 2 4)))
            )
            (princ "\n[STEP5] bbox failed")
          )
        )
      )
    )
  )
  (princ)
)

(defun c:S5MARK ( / )
  (setq *S5-MARK* (entlast))
  (princ (strcat "\n[STEP5] mark=" (if *S5-MARK* (cdr (assoc 5 (entget *S5-MARK*))) "nil")))
  (princ)
)

(defun c:S5MOVETOP (tx ty) (s5:move-new tx ty "TOP"))
(defun c:S5MOVELB  (tx ty) (s5:move-new tx ty "LB"))

(defun c:S5NEWBB ( / bb)
  (setq bb (s5:newbb))
  (if bb
    (princ (strcat "\nNEWBB " (rtos (car bb) 2 4) " " (rtos (cadr bb) 2 4) " "
                   (rtos (caddr bb) 2 4) " " (rtos (cadddr bb) 2 4)))
    (princ "\nNEWBB none")
  )
  (princ)
)

;; ���ص� (x,y) ʰȡ����ʵ������д�� *S5-PICKFILE*��ÿ��һ�����������д NONE��
(defun c:S5PICKAT (x y / ss i f h)
  (if (null *S5-PICKFILE*) (setq *S5-PICKFILE* "E:/AI-Workspace/Logs/_s5_pick.txt"))
  (setq f (open *S5-PICKFILE* "w"))
  (setq ss (ssget (list x y)))
  (if ss
    (progn
      (setq i 0)
      (repeat (sslength ss)
        (write-line (cdr (assoc 5 (entget (ssname ss i)))) f)
        (setq i (1+ i))
      )
    )
    (write-line "NONE" f)
  )
  (close f)
  (princ)
)
