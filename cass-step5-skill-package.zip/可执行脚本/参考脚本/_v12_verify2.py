# -*- coding: utf-8 -*-
import csv, io, math, os, re

OUT = r"E:\AI-Workspace\Output\STEP5回归"
LOG = r"E:\AI-Workspace\Logs"
lines=[]
def w(s): lines.append(s)

def load(t):
    return list(csv.DictReader(io.open(os.path.join(LOG,"_v12_%s.tsv"%t),encoding="utf-8"),delimiter="\t"))
def num(v):
    try: return float(v)
    except: return None
def bbox(r): return (num(r["XMIN"]),num(r["YMIN"]),num(r["XMAX"]),num(r["YMAX"]))
def overlap(a,b,tol=0.0):
    return not (a[2] <= b[0]+tol or b[2] <= a[0]+tol or a[3] <= b[1]+tol or b[3] <= a[1]+tol)
def dbox(x,y,b):
    dx=max(b[0]-x,0.0,x-b[2]); dy=max(b[1]-y,0.0,y-b[3]); return math.hypot(dx,dy)
def cluster_y(boxes,gap=1.0):
    boxes=sorted(boxes,key=lambda b:b[1]); clusters=[]
    for b in boxes:
        if clusters and b[1]-clusters[-1][3] <= gap:
            c=clusters[-1]; clusters[-1]=(min(c[0],b[0]),min(c[1],b[1]),max(c[2],b[2]),max(c[3],b[3]))
        else: clusters.append(b)
    return clusters

expect={"T1":(1,[17]),"T2":(1,[8]),"T3":(3,[4,4,6])}
ok_all=True
for t in ("T1","T2","T3"):
    rows=load(t)
    parcels=[r for r in rows if r["LAYER"]=="JZD" and r["OBJNAME"]=="AcDb2dPolyline"]
    circles=[r for r in rows if r["LAYER"]=="JZP" and r["OBJNAME"]=="AcDbCircle"]
    labels=[r for r in rows if r["LAYER"]=="JZP" and r["OBJNAME"]=="AcDbText" and re.match(r"^J\d+$",r["TEXT"].strip())]
    tk=[r for r in rows if r["LAYER"]=="tk"]
    pboxes=[bbox(r) for r in parcels]
    tclusters=cluster_y([bbox(r) for r in tk],1.0)
    csvp=os.path.join(OUT,"%s_V12_V12地块清单.csv"%t)
    nos=[]
    if os.path.exists(csvp):
        with io.open(csvp,encoding="utf-8-sig") as f:
            for row in csv.DictReader(f): nos.append(row.get("ParcelNo",""))
    w("="*72)
    w("【%s】实体=%d 权属线=%d 界址点=%d 点号=%d 表格实体=%d 表格簇=%d"%(t,len(rows),len(parcels),len(circles),len(labels),len(tk),len(tclusters)))
    w("  宗地号: "+", ".join(nos))
    exp_p,exp_v=expect[t]; ok=True
    if len(parcels)!=exp_p: w("  [FAIL] 权属线数量 %d != %d"%(len(parcels),exp_p)); ok=False
    if len(tclusters)!=exp_p: w("  [FAIL] 表格数量 %d != %d"%(len(tclusters),exp_p)); ok=False
    for i,pb in enumerate(pboxes):
        pts=[c for c in circles if dbox(num(c["XMIN"])+0.3,num(c["YMIN"])+0.3,pb)<=0.5]
        w("  地块%d bbox=(%.3f,%.3f)-(%.3f,%.3f) 面积=%.3f 界址点=%d"%(i+1,pb[0],pb[1],pb[2],pb[3],num(parcels[i]["AREA"]),len(pts)))
        if len(pts)!=exp_v[i]: w("     [FAIL] 界址点数 %d != 顶点 %d"%(len(pts),exp_v[i])); ok=False
        mine=[]
        for x in labels:
            lx=num(x["XMIN"]); ly=num(x["YMIN"])
            d=[dbox(lx,ly,b) for b in pboxes]
            if d[i]==min(d): mine.append(x["TEXT"].strip())
        want=set("J%d"%k for k in range(1,exp_v[i]+1))
        if set(mine)!=want: w("     [FAIL] 点号集合不符: %s"%sorted(mine)); ok=False
    for i,tb in enumerate(tclusters):
        hit=[j+1 for j,pb in enumerate(pboxes) if overlap(tb,pb)]
        if hit: w("  [FAIL] 表格%d 与地块%s 重叠"%(i+1,hit)); ok=False
        w("  表格%d bbox=(%.3f,%.3f)-(%.3f,%.3f) 高=%.3f 宽=%.3f"%(i+1,tb[0],tb[1],tb[2],tb[3],tb[3]-tb[1],tb[2]-tb[0]))
    for i in range(len(tclusters)):
        for j in range(i+1,len(tclusters)):
            if overlap(tclusters[i],tclusters[j]):
                w("  [FAIL] 表格%d 与表格%d 重叠"%(i+1,j+1)); ok=False
    w("  结论: " + ("PASS" if ok else "FAIL"))
    if not ok: ok_all=False

w("")
w("总体: " + ("全部通过" if ok_all else "存在失败项"))
io.open(os.path.join(OUT,"V12_回归核查报告.txt"),"w",encoding="utf-8-sig").write("\r\n".join(lines))
print("written")
