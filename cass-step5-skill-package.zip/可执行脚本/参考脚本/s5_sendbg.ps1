﻿param([string]$Cmd='')
$acad=[Runtime.InteropServices.Marshal]::GetActiveObject('AutoCAD.Application')
$doc=$acad.ActiveDocument
$doc.SendCommand($Cmd)
"sent at " + (Get-Date -Format HH:mm:ss)
