(defun c:S5MOVE ( / ss i)
  (setq ss (ssget "_X" (list (cons 8 "tk"))))
  (if ss
    (progn
      (command "_.MOVE" ss "" (list 0 0) (list 0 35))
      (princ (strcat "\nMOVED " (itoa (sslength ss))))
    )
    (princ "\nNO TK ENTITIES")
  )
  (princ)
)
