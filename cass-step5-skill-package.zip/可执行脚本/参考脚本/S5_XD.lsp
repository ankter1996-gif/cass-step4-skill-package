(defun c:S5XD ( / f e ed xd)
  (setq f (open "E:/AI-Workspace/Logs/_s5_xdata.txt" "w"))
  (setq e (entnext))
  (while e
    (setq ed (entget e '("SOUTH" "CASS" "*")))
    (setq xd (assoc -3 ed))
    (if xd (progn
      (write-line (strcat "HANDLE=" (cdr (assoc 5 ed)) " TYPE=" (cdr (assoc 0 ed)) " LAYER=" (cdr (assoc 8 ed))) f)
      (write-line (vl-princ-to-string xd) f)))
    (setq e (entnext e))
  )
  (close f)
  (princ)
)
