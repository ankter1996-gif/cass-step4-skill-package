﻿param([string]$TitleLike='',[int]$Key=0x0D)
$ErrorActionPreference='Stop'
Add-Type @"
using System; using System.Text; using System.Runtime.InteropServices;
public class DlgK {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr l);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
  public static IntPtr Find(uint pid, string like){
    IntPtr res=IntPtr.Zero;
    EnumWindows((h,l)=>{
      uint p; GetWindowThreadProcessId(h,out p);
      if(p==pid && IsWindowVisible(h)){
        var t=new StringBuilder(256); GetWindowText(h,t,256);
        if(like=="" || t.ToString().Contains(like)){ res=h; return false; }
      }
      return true;
    }, IntPtr.Zero);
    return res;
  }
  public static void Key(IntPtr h, int vk){
    PostMessage(h,0x0100,(IntPtr)vk,IntPtr.Zero);
    System.Threading.Thread.Sleep(60);
    PostMessage(h,0x0101,(IntPtr)vk,IntPtr.Zero);
  }
}
"@
$p=Get-Process acad | Select-Object -First 1
$h=[DlgK]::Find([uint32]$p.Id, $TitleLike)
if($h -eq [IntPtr]::Zero){ "DIALOG NOT FOUND"; exit 3 }
"dialog=0x{0:X}" -f [int64]$h
[DlgK]::Key($h,$Key)
Start-Sleep -Seconds 2
"key sent"
