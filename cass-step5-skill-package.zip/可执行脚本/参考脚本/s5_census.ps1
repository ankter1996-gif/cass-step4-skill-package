param(
    [string]$Path = '',
    [Parameter(Mandatory=$true)][string]$OutFile,
    [string]$Close = 'no'
)
$ErrorActionPreference = 'Stop'
$acad = $null
for ($t = 0; $t -lt 20 -and -not $acad; $t++) {
    try { $acad = [Runtime.InteropServices.Marshal]::GetActiveObject('AutoCAD.Application') } catch { Start-Sleep -Seconds 2 }
}
if (-not $acad) { Write-Output "ATTACH-FAIL"; exit 4 }

if ($Path -ne '') {
    $doc = $acad.Documents.Open($Path)
    Start-Sleep -Seconds 3
} else {
    $doc = $acad.ActiveDocument
}
Write-Output ("doc: " + $doc.FullName + "  entities=" + $doc.ModelSpace.Count)

$ms = $doc.ModelSpace
$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("IDX`tOBJNAME`tLAYER`tHANDLE`tCOLOR`tXMIN`tYMIN`tXMAX`tYMAX`tLEN`tAREA`tTEXT")

for ($i = 0; $i -lt $ms.Count; $i++) {
    $e = $ms.Item($i)
    $nm=''; $ly=''; $hd=''; $co=''
    try { $nm = $e.ObjectName } catch { }
    try { $ly = $e.Layer } catch { }
    try { $hd = $e.Handle } catch { }
    try { $co = $e.color } catch { }
    $x1=''; $y1=''; $x2=''; $y2=''; $ln=''; $ar=''
    try {
        $mn = $null; $mx = $null
        $e.GetBoundingBox([ref]$mn, [ref]$mx)
        if ($mn -ne $null -and $mx -ne $null) {
            $x1=[math]::Round($mn[0],3); $y1=[math]::Round($mn[1],3)
            $x2=[math]::Round($mx[0],3); $y2=[math]::Round($mx[1],3)
        }
    } catch { }
    try { if ($nm -match 'Polyline|Line|Arc|Circle') { $ln = [math]::Round($e.Length,3) } } catch { }
    try { if ($nm -match 'Polyline|Region|Circle|Hatch') { $ar = [math]::Round($e.Area,3) } } catch { }
    $tx = ''
    try {
        switch ($nm) {
            'AcDbText'  { $tx = $e.TextString }
            'AcDbMText' { $tx = $e.TextString }
            'AcDbBlockReference' { $tx = 'BLOCK=' + $e.Name }
            'AcDbHatch' { $tx = 'PAT=' + $e.PatternName }
        }
    } catch { }
    $tx = ($tx -replace "`r?`n", ' ')
    $lines.Add(("{0}`t{1}`t{2}`t{3}`t{4}`t{5}`t{6}`t{7}`t{8}`t{9}`t{10}`t{11}" -f $i,$nm,$ly,$hd,$co,$x1,$y1,$x2,$y2,$ln,$ar,$tx))
}
[System.IO.File]::WriteAllLines($OutFile, $lines, (New-Object System.Text.UTF8Encoding($false)))
Write-Output ("tsv: " + $OutFile)

if ($Close -eq 'yes') { $doc.Close($false) }
