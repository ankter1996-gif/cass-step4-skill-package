﻿<#
================================================================================
 STEP5_Run_V1.2.ps1 — CASS10 单/多地块：权属线 + 界址点 + 界址点坐标表
 版本 V1.2   2026-11-13
--------------------------------------------------------------------------------
 相对 V1.1 的改动（按用户 9 条要求）：
   1. 目标地块：支持 -Handles / -ParcelListFile / -All，不再“取最大面积”；
      每个地块独立转换、独立 J1 起编号、独立一张坐标表。
   2. 界址点检查：只核对本轮新增的 JZP 圆圈，且其 ZDDJH 必须等于当前权属线宗地号。
   3. 坐标表移动：先 S5MARK 再 JZDZB；只移动标记之后新建的实体；移动后核对包围盒。
   4. 命令状态：以 CMDACTIVE + 实体数 + 对话框状态判定完成；COM 拒绝调用时受限重试，
      不因读取 Count 失败而中断。
   5. 系统变量：记录 RECOVERYMODE/FILEDIA/LOGFILEMODE/LOGFILEPATH 原值，finally 恢复。
   6. 错误处理：逐地块 try/catch，记录阶段/原因；失败地块不写入成功汇总。
   7. 文件安全：源图只读；输出已存在时默认拒绝覆盖（-Force 才覆盖）；已转换地块跳过。
   8. 坐标自适应：最长边中点 + 拾取校验 + 质心/网格内点 + 按实测包围盒摆放表格；
      表格统一放在所有地块右侧并按高度堆叠，避免与地块/其它表格重叠。
   9. 宗地编号：不修改 CASS 全局库；记录实际生成的宗地号（权属线 south 扩展数据）。
--------------------------------------------------------------------------------
 依赖：CASS 10.1.6 For AutoCAD 2016（/p Cass10.1 常驻）、Windows PowerShell 5.1、
       STEP5_Tools.lsp（同目录）
================================================================================
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$SrcDwg,
    [Parameter(Mandatory=$true)][string]$OutDwg,
    [string]$LogFile = '',
    [string[]]$Handles = @(),
    [string]$ParcelListFile = '',
    [switch]$All,
    [string[]]$Layers = @(),
    [string[]]$ExcludeLayers = @('JZP', 'tk'),
    [string]$RestoreFrom = '',
    [switch]$Force,
    [string]$ToolsLsp = '',
    [double]$GapRatio = 0.08,
    [int]$TimeoutSec = 120
)

$ErrorActionPreference = 'Stop'
$script:Inv = [Globalization.CultureInfo]::InvariantCulture
$script:LogPath = $null
$script:LogLines = New-Object System.Collections.Generic.List[string]
$script:Utf8 = New-Object System.Text.UTF8Encoding($true)

function Write-Log([string]$msg, [string]$level = 'INFO') {
    $line = "[{0}] [{1}] {2}" -f (Get-Date -Format 'HH:mm:ss'), $level, $msg
    $script:LogLines.Add($line)
    Write-Host $line
    if ($script:LogPath) {
        try { [IO.File]::AppendAllText($script:LogPath, $line + "`r`n", $script:Utf8) } catch { }
    }
}
function N3([double]$v) { return $v.ToString('0.000', $script:Inv) }

# ------------------------------------------------------------------ COM 基础
function Get-AcadApp {
    for ($i = 0; $i -lt 40; $i++) {
        try {
            $a = [Runtime.InteropServices.Marshal]::GetActiveObject('AutoCAD.Application')
            if ($a) { return $a }
        } catch { }
        Start-Sleep -Milliseconds 500
    }
    throw '未能连接到运行中的 CASS/AutoCAD'
}

function Try-Com([scriptblock]$sb, [int]$tries = 30, [int]$delayMs = 300) {
    for ($i = 0; $i -lt $tries; $i++) {
        try { return (& $sb) } catch { Start-Sleep -Milliseconds $delayMs }
    }
    return $null
}

function Get-CmdActive([object]$doc) {
    # 返回 0/1，读取被拒绝时返回 $null（视为忙）
    try { return [int]$doc.GetVariable('CMDACTIVE') } catch { return $null }
}

function Get-EntCount([object]$doc) {
    # ModelSpace.Count 偶发返回 0（图形重生成中），重试以避免误判
    for ($k = 0; $k -lt 8; $k++) {
        try { $c = [int]$doc.ModelSpace.Count; if ($c -gt 0) { return $c } } catch { }
        Start-Sleep -Milliseconds 200
    }
    try { return [int]$doc.ModelSpace.Count } catch { return -1 }
}

function Get-Space([object]$doc, [int]$minCount = 1) {
    for ($k = 0; $k -lt 25; $k++) {
        try { $sp = $doc.ModelSpace; $c = [int]$sp.Count; if ($c -ge $minCount) { return @{ Space = $sp; Count = $c } } } catch { }
        Start-Sleep -Milliseconds 300
    }
    return $null
}

# ------------------------------------------------------------------ Win32
if (-not ('S5Win2' -as [type])) {
Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public class S5Win2 {
    public delegate bool EnumProc(IntPtr h, IntPtr l);
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr l);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
    public static IntPtr Find(uint pid, string like) {
        IntPtr res = IntPtr.Zero;
        EnumWindows((h, l) => {
            uint p; GetWindowThreadProcessId(h, out p);
            if (p == pid && IsWindowVisible(h)) {
                var t = new StringBuilder(256); GetWindowText(h, t, 256);
                if (t.ToString().Contains(like)) { res = h; return false; }
            }
            return true;
        }, IntPtr.Zero);
        return res;
    }
    public static void Enter(IntPtr h) {
        PostMessage(h, 0x0100, (IntPtr)0x0D, IntPtr.Zero);
        System.Threading.Thread.Sleep(60);
        PostMessage(h, 0x0101, (IntPtr)0x0D, IntPtr.Zero);
    }
}
"@
}

function Wait-Command {
    param([object]$doc, [int]$pidAcad, [int]$countBefore, [int]$timeoutSec, [string]$dialogTitle = '')
    $startTime = Get-Date
    $deadline = $startTime.AddSeconds($timeoutSec)
    $confirmed = $false

    # 阶段1：若命令会弹模态框，先等它出现并回车确认（不因 CMDACTIVE 瞬时为 0 而提前退出）
    if ($dialogTitle -ne '') {
        while ((Get-Date) -lt $deadline) {
            $h = [S5Win2]::Find([uint32]$pidAcad, $dialogTitle)
            if ($h -ne [IntPtr]::Zero) {
                Start-Sleep -Milliseconds 700
                [S5Win2]::Enter($h)
                Start-Sleep -Milliseconds 1200
                if ([S5Win2]::Find([uint32]$pidAcad, $dialogTitle) -eq [IntPtr]::Zero) { $confirmed = $true; break }
            }
            Start-Sleep -Milliseconds 300
        }
        if (-not $confirmed) { return @{ Done = $false; Dialog = $false; Count = (Get-EntCount $doc) } }
    }

    # 阶段2：等命令真正结束（实体增加且空闲，或持续空闲）
    $idle = 0
    while ((Get-Date) -lt $deadline) {
        $act = Get-CmdActive $doc
        $cnt = Get-EntCount $doc
        if ($act -eq 0 -and $cnt -gt $countBefore) { return @{ Done = $true; Dialog = $confirmed; Count = $cnt } }
        if ($act -eq 0) { $idle++ } else { $idle = 0 }
        if ($idle -ge 8) { return @{ Done = ($cnt -gt $countBefore); Dialog = $confirmed; Count = $cnt } }
        Start-Sleep -Milliseconds 400
    }
    return @{ Done = $false; Dialog = $confirmed; Count = (Get-EntCount $doc) }
}

function Send-Queued([object]$doc, [string]$cmd) {
    for ($i = 0; $i -lt 40; $i++) {
        try { $doc.SendCommand($cmd); return $true } catch { Start-Sleep -Milliseconds 400 }
    }
    return $false
}

# 异步发送（用于会弹出模态框的命令：SendCommand 会被对话框阻塞，必须在独立进程中执行）
function Send-QueuedAsync([string]$cmd) {
    $f = Join-Path $env:TEMP ('s5cmd_' + [guid]::NewGuid().ToString('N') + '.txt')
    [IO.File]::WriteAllText($f, $cmd, (New-Object Text.UTF8Encoding($false)))
    $helper = Join-Path $PSScriptRoot 'STEP5_SendCmd.ps1'
    Start-Process powershell -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $helper + '"'),'-CmdFile',('"' + $f + '"') -WindowStyle Hidden | Out-Null
    return $f
}

# ------------------------------------------------------------------ 几何
function Get-Vertices([object]$ent) {
    $pts = New-Object System.Collections.Generic.List[object]
    $c = $ent.Coordinates
    if ($ent.ObjectName -eq 'AcDbPolyline') {
        for ($i = 0; $i + 1 -lt $c.Length; $i += 2) { $pts.Add([pscustomobject]@{ X = [double]$c[$i]; Y = [double]$c[$i + 1] }) }
    } else {
        for ($i = 0; $i + 2 -lt $c.Length; $i += 3) { $pts.Add([pscustomobject]@{ X = [double]$c[$i]; Y = [double]$c[$i + 1] }) }
    }
    return ,$pts
}
function Get-BBox($pts) {
    $xs = $pts | ForEach-Object { $_.X }
    $ys = $pts | ForEach-Object { $_.Y }
    return [pscustomobject]@{
        MinX = ($xs | Measure-Object -Minimum).Minimum
        MaxX = ($xs | Measure-Object -Maximum).Maximum
        MinY = ($ys | Measure-Object -Minimum).Minimum
        MaxY = ($ys | Measure-Object -Maximum).Maximum
    }
}
function Test-InPoly($pts, [double]$x, [double]$y) {
    $inside = $false; $n = $pts.Count; $j = $n - 1
    for ($i = 0; $i -lt $n; $i++) {
        $xi = $pts[$i].X; $yi = $pts[$i].Y; $xj = $pts[$j].X; $yj = $pts[$j].Y
        if ((($yi -gt $y) -ne ($yj -gt $y)) -and ($x -lt ($xj - $xi) * ($y - $yi) / ($yj - $yi) + $xi)) { $inside = -not $inside }
        $j = $i
    }
    return $inside
}
function Get-SegDist($pts, [double]$x, [double]$y) {
    $min = [double]::MaxValue; $n = $pts.Count
    for ($i = 0; $i -lt $n; $i++) {
        $j = ($i + 1) % $n
        $ax = $pts[$i].X; $ay = $pts[$i].Y; $bx = $pts[$j].X; $by = $pts[$j].Y
        $dx = $bx - $ax; $dy = $by - $ay; $l2 = $dx * $dx + $dy * $dy
        $t = 0.0
        if ($l2 -gt 0) { $t = (($x - $ax) * $dx + ($y - $ay) * $dy) / $l2; if ($t -lt 0) { $t = 0 } elseif ($t -gt 1) { $t = 1 } }
        $px = $ax + $t * $dx; $py = $ay + $t * $dy
        $d = [math]::Sqrt(($x - $px) * ($x - $px) + ($y - $py) * ($y - $py))
        if ($d -lt $min) { $min = $d }
    }
    return $min
}
function Get-Interior($pts) {
    $a = 0.0; $cx = 0.0; $cy = 0.0; $n = $pts.Count
    for ($i = 0; $i -lt $n; $i++) {
        $j = ($i + 1) % $n
        $cr = $pts[$i].X * $pts[$j].Y - $pts[$j].X * $pts[$i].Y
        $a += $cr; $cx += ($pts[$i].X + $pts[$j].X) * $cr; $cy += ($pts[$i].Y + $pts[$j].Y) * $cr
    }
    $a = $a / 2.0
    $bb0 = Get-BBox $pts
    $need = [math]::Max([math]::Min(($bb0.MaxX - $bb0.MinX), ($bb0.MaxY - $bb0.MinY)) * 0.06, 0.5)
    if ([math]::Abs($a) -gt 1e-9) {
        $cx = $cx / (6.0 * $a); $cy = $cy / (6.0 * $a)
        # 质心在多边形内且离边界足够远才采用（凹多边形质心可能贴近缺口边）
        if ((Test-InPoly $pts $cx $cy) -and ((Get-SegDist $pts $cx $cy) -ge $need)) {
            return [pscustomobject]@{ X = $cx; Y = $cy }
        }
    }
    $bb = Get-BBox $pts
    $best = $null; $bd = -1.0
    $steps = 60
    for ($ix = 1; $ix -lt $steps; $ix++) {
        for ($iy = 1; $iy -lt $steps; $iy++) {
            $x = $bb.MinX + ($bb.MaxX - $bb.MinX) * $ix / $steps
            $y = $bb.MinY + ($bb.MaxY - $bb.MinY) * $iy / $steps
            if (Test-InPoly $pts $x $y) {
                $d = Get-SegDist $pts $x $y
                if ($d -gt $bd) { $bd = $d; $best = [pscustomobject]@{ X = $x; Y = $y } }
            }
        }
    }
    return $best
}
function Get-EdgeCandidates($pts) {
    $list = New-Object System.Collections.Generic.List[object]
    $n = $pts.Count
    for ($i = 0; $i -lt $n; $i++) {
        $j = ($i + 1) % $n
        $dx = $pts[$j].X - $pts[$i].X; $dy = $pts[$j].Y - $pts[$i].Y
        $L = [math]::Sqrt($dx * $dx + $dy * $dy)
        $list.Add([pscustomobject]@{ L = $L; X = ($pts[$i].X + $pts[$j].X) / 2.0; Y = ($pts[$i].Y + $pts[$j].Y) / 2.0 })
    }
    return ,($list | Sort-Object -Property L -Descending)
}
function Zoom-Window([object]$doc, [double]$x1, [double]$y1, [double]$x2, [double]$y2) {
    $cmd = '(command "_.ZOOM" "_W" (list ' + (N3 $x1) + ' ' + (N3 $y1) + ') (list ' + (N3 $x2) + ' ' + (N3 $y2) + ')) '
    Send-Queued $doc $cmd | Out-Null
    Start-Sleep -Milliseconds 900
}

# ------------------------------------------------------------------ XData
function Get-XVal([object]$ent, [string]$app, [int]$index) {
    $xt = $null; $xv = $null
    try { $ent.GetXData($app, [ref]$xt, [ref]$xv) } catch { return $null }
    if ($null -eq $xv) { return $null }
    if ($index -lt 0 -or $index -ge $xv.Length) { return $null }
    return [string]$xv[$index]
}

# ------------------------------------------------------------------ 完整性判定 / 拾取 / 表格
function Get-TkClusters([object]$ms) {
    $items = New-Object System.Collections.Generic.List[object]
    for ($i = 0; $i -lt $ms.Count; $i++) {
        $e = $ms.Item($i)
        try { if ($e.Layer -ne 'tk') { continue } } catch { continue }
        $mn = $null; $mx = $null
        try { $e.GetBoundingBox([ref]$mn, [ref]$mx) } catch { continue }
        if ($null -eq $mn) { continue }
        $txt = ''
        if ($e.ObjectName -eq 'AcDbText') { try { $txt = [string]$e.TextString } catch { } }
        $items.Add([pscustomobject]@{ Obj = $e.ObjectName; Text = $txt; MinX = $mn[0]; MinY = $mn[1]; MaxX = $mx[0]; MaxY = $mx[1] }) | Out-Null
    }
    $sorted = @($items | Sort-Object -Property MinY)
    $clusters = New-Object System.Collections.Generic.List[object]
    foreach ($it in $sorted) {
        if ($clusters.Count -gt 0) {
            $last = $clusters[$clusters.Count - 1]
            if ($it.MinY -le ($last.MaxY + 1.0)) {
                $last.MinX = [math]::Min($last.MinX, $it.MinX)
                $last.MinY = [math]::Min($last.MinY, $it.MinY)
                $last.MaxX = [math]::Max($last.MaxX, $it.MaxX)
                $last.MaxY = [math]::Max($last.MaxY, $it.MaxY)
                $last.Items.Add($it) | Out-Null
                continue
            }
        }
        $cl = [pscustomobject]@{ MinX = $it.MinX; MinY = $it.MinY; MaxX = $it.MaxX; MaxY = $it.MaxY; Items = (New-Object System.Collections.Generic.List[object]) }
        $cl.Items.Add($it) | Out-Null
        $clusters.Add($cl) | Out-Null
    }
    return ,$clusters
}

function Test-TableForParcel($cl, $pts) {
    $n = $pts.Count
    $jt = @($cl.Items | Where-Object { $_.Obj -eq 'AcDbText' -and $_.Text -match '^J\d+$' })
    if ($jt.Count -ne ($n + 1)) { return $false }
    $nums = @($cl.Items | Where-Object { $_.Obj -eq 'AcDbText' -and $_.Text -match '^-?\d+(\.\d+)?$' })
    $bad = 0
    foreach ($j in $jt) {
        $row = @($nums | Where-Object { [math]::Abs($_.MinY - $j.MinY) -le 0.8 -and $_.MinX -gt $j.MinX } | Sort-Object -Property MinX)
        if ($row.Count -lt 2) { $bad++; continue }
        $X = [double]$row[0].Text; $Y = [double]$row[1].Text
        $d = [double]::MaxValue
        foreach ($p in $pts) {
            $dd = [math]::Sqrt(($Y - $p.X) * ($Y - $p.X) + ($X - $p.Y) * ($X - $p.Y))
            if ($dd -lt $d) { $d = $dd }
        }
        if ($d -gt 0.02) { $bad++ }
    }
    return ($bad -eq 0)
}

function Test-ParcelState {
    param([object]$doc, $pts, [string]$no, [string]$qhdm)
    $n = $pts.Count
    $expectZ = $no
    if ($qhdm) { $expectZ = $qhdm + $no }
    $sp = Get-Space $doc 1
    if ($null -eq $sp) { return [pscustomobject]@{ PointsOk = $false; LabelsOk = $false; TableOk = $false; Complete = $false; Points = 0; Summary = '无法读取模型空间' } }
    $ms = $sp.Space
    $allCircles = New-Object System.Collections.Generic.List[object]
    $texts = New-Object System.Collections.Generic.List[object]
    for ($i = 0; $i -lt $ms.Count; $i++) {
        $e = $ms.Item($i)
        try {
            if ($e.Layer -ne 'JZP') { continue }
            $mn = $null; $mx = $null
            if ($e.ObjectName -eq 'AcDbCircle') {
                $e.GetBoundingBox([ref]$mn, [ref]$mx)
                if ($null -eq $mn) { continue }
                $allCircles.Add([pscustomobject]@{ X = $mn[0] + 0.3; Y = $mn[1] + 0.3; Key = (Get-XVal $e 'ZDDJH' 1) }) | Out-Null
            } elseif ($e.ObjectName -eq 'AcDbText') {
                $e.GetBoundingBox([ref]$mn, [ref]$mx)
                if ($null -eq $mn) { continue }
                $texts.Add([pscustomobject]@{ T = [string]$e.TextString; X = $mn[0]; Y = $mn[1] }) | Out-Null
            }
        } catch { }
    }
    # 本块界址点
    $mine = New-Object System.Collections.Generic.List[object]
    foreach ($c in $allCircles) {
        if (-not $c.Key) { continue }
        if ($c.Key -eq $expectZ -or $c.Key.EndsWith($no)) { $mine.Add($c) | Out-Null }
    }
    $geomOk = $true
    foreach ($c in $mine) {
        $d = [double]::MaxValue
        foreach ($p in $pts) {
            $dd = [math]::Sqrt(($c.X - $p.X) * ($c.X - $p.X) + ($c.Y - $p.Y) * ($c.Y - $p.Y))
            if ($dd -lt $d) { $d = $dd }
        }
        if ($d -gt 0.01) { $geomOk = $false }
    }
    $pointsOk = ($mine.Count -eq $n) -and $geomOk
    # 点号：归属到最近的界址点，且该点属于本块
    $labels = @()
    foreach ($t in $texts) {
        if ($t.T -notmatch '^J\d+$') { continue }
        $bestI = -1; $bestD = [double]::MaxValue
        for ($k = 0; $k -lt $allCircles.Count; $k++) {
            $c = $allCircles[$k]
            $dd = [math]::Sqrt(($t.X - $c.X) * ($t.X - $c.X) + ($t.Y - $c.Y) * ($t.Y - $c.Y))
            if ($dd -lt $bestD) { $bestD = $dd; $bestI = $k }
        }
        if ($bestI -ge 0 -and $bestD -le 6.0) {
            $bc = $allCircles[$bestI]
            if ($bc.Key -and ($bc.Key -eq $expectZ -or $bc.Key.EndsWith($no))) { $labels += $t.T }
        }
    }
    $want = @()
    for ($k = 1; $k -le $n; $k++) { $want += ('J' + $k) }
    $labelsOk = ((($labels | Sort-Object { [int]($_ -replace '[^0-9]', '') }) -join ',') -eq ($want -join ','))
    $tableOk = $false
    $clusters = Get-TkClusters $ms
    foreach ($cl in $clusters) {
        if (Test-TableForParcel $cl $pts) { $tableOk = $true }
    }
    $complete = $pointsOk -and $labelsOk -and $tableOk
    $s1 = '权属线=有 界址点=' + $mine.Count + '/' + $n
    if ($labelsOk) { $s1 = $s1 + ' 点号=J1..J' + $n } else { $s1 = $s1 + ' 点号=异常(' + ($labels -join ',') + ')' }
    if ($tableOk) { $s1 = $s1 + ' 坐标表=有' } else { $s1 = $s1 + ' 坐标表=无' }
    return [pscustomobject]@{ PointsOk = $pointsOk; LabelsOk = $labelsOk; TableOk = $tableOk; Complete = $complete; Points = $mine.Count; Summary = $s1 }
}

function Find-PickPoint {
    param([object]$doc, [string]$h, $pts, $bb)
    $margin = [math]::Max(($bb.MaxX - $bb.MinX) * 0.3, 5.0)
    Zoom-Window $doc ($bb.MinX - $margin) ($bb.MinY - $margin) ($bb.MaxX + $margin) ($bb.MaxY + $margin)
    $edge = Get-EdgeCandidates $pts
    $tryN = [math]::Min(5, $edge.Count)
    for ($k = 0; $k -lt $tryN; $k++) {
        $px = $edge[$k].X; $py = $edge[$k].Y
        Send-Queued $doc ('(setq *S5-PICKFILE* "E:/AI-Workspace/Logs/_s5_pick.txt") (c:S5PICKAT ' + (N3 $px) + ' ' + (N3 $py) + ') ') | Out-Null
        Start-Sleep -Milliseconds 900
        $got = @(Get-Content 'E:\AI-Workspace\Logs\_s5_pick.txt' -ErrorAction SilentlyContinue)
        if ($got.Count -eq 1 -and $got[0].Trim().ToUpper() -eq $h) { return [pscustomobject]@{ Ok = $true; X = $px; Y = $py } }
    }
    return [pscustomobject]@{ Ok = $false; X = 0.0; Y = 0.0 }
}

function Ensure-Table {
    param([object]$doc, [int]$pidAcad, $pts, $bb, [double]$pickX, [double]$pickY, [double]$slotX, [double]$topY)
    $sp = Get-Space $doc 1
    if ($null -eq $sp) { return @{ Ok = $false; Entities = 0; Error = '无法读取模型空间'; MinY = 0.0; MaxY = 0.0 } }
    $ms = $sp.Space
    $tkBefore = New-Object System.Collections.Generic.HashSet[string]
    for ($i = 0; $i -lt $ms.Count; $i++) {
        $e = $ms.Item($i)
        try { if ($e.Layer -eq 'tk') { $tkBefore.Add(([string]$e.Handle).ToUpper()) | Out-Null } } catch { }
    }
    Send-Queued $doc '(c:S5MARK) ' | Out-Null
    Start-Sleep -Milliseconds 700
    $before = [int]$ms.Count
    $tpx = $bb.MinX
    $tpy = $bb.MaxY + [math]::Max(($bb.MaxY - $bb.MinY) * $GapRatio, 1.0)
    $cmd = 'JZDZB' + "`n" + (N3 $tpx) + ',' + (N3 $tpy) + "`n" + "`n" + (N3 $pickX) + ',' + (N3 $pickY) + "`n"
    Send-Queued $doc $cmd | Out-Null
    $res = Wait-Command -doc $doc -pidAcad $pidAcad -countBefore $before -timeoutSec $TimeoutSec
    if (-not $res.Done -or $res.Count -le $before) {
        return @{ Ok = $false; Entities = 0; Error = ('JZDZB 未生成表格 done=' + $res.Done); MinY = 0.0; MaxY = 0.0 }
    }
    Start-Sleep -Milliseconds 600
    $sp2 = Get-Space $doc ($before + 1)
    if ($sp2) { $ms = $sp2.Space }
    $handles = New-Object System.Collections.Generic.HashSet[string]
    for ($i = 0; $i -lt $ms.Count; $i++) {
        $e = $ms.Item($i)
        try { if ($e.Layer -ne 'tk') { continue } } catch { continue }
        $hh = ([string]$e.Handle).ToUpper()
        if ($tkBefore.Contains($hh)) { continue }
        $handles.Add($hh) | Out-Null
    }
    if ($handles.Count -eq 0) { return @{ Ok = $false; Entities = 0; Error = '未找到新生成的表格实体'; MinY = 0.0; MaxY = 0.0 } }
    Send-Queued $doc ('(c:S5MOVETOP ' + (N3 $slotX) + ' ' + (N3 $topY) + ') ') | Out-Null
    Start-Sleep -Seconds 2
    $minx = [double]::MaxValue; $miny = [double]::MaxValue
    $maxx = [double]::MinValue; $maxy = [double]::MinValue
    foreach ($th in $handles) {
        $e = $doc.HandleToObject($th)
        if ($null -eq $e) { continue }
        $mn = $null; $mx = $null
        try { $e.GetBoundingBox([ref]$mn, [ref]$mx) } catch { continue }
        if ($null -eq $mn) { continue }
        if ($mn[0] -lt $minx) { $minx = $mn[0] }
        if ($mn[1] -lt $miny) { $miny = $mn[1] }
        if ($mx[0] -gt $maxx) { $maxx = $mx[0] }
        if ($mx[1] -gt $maxy) { $maxy = $mx[1] }
    }
    $devX = [math]::Abs($minx - $slotX); $devY = [math]::Abs($maxy - $topY)
    Write-Log ('表格: 实体=' + $handles.Count + ' 包围盒=(' + (N3 $minx) + ',' + (N3 $miny) + ')-(' + (N3 $maxx) + ',' + (N3 $maxy) + ') 偏差 dx=' + (N3 $devX) + ' dy=' + (N3 $devY))
    if ($devX -gt 0.05 -or $devY -gt 0.05) {
        return @{ Ok = $false; Entities = $handles.Count; Error = ('表格对齐偏差过大 dx=' + (N3 $devX) + ' dy=' + (N3 $devY)); MinY = $miny; MaxY = $maxy }
    }
    return @{ Ok = $true; Entities = $handles.Count; Error = ''; MinY = $miny; MaxY = $maxy }
}

# ------------------------------------------------------------------ 主流程
$t0 = Get-Date
$srcFull = [IO.Path]::GetFullPath($SrcDwg)
$outFull = [IO.Path]::GetFullPath($OutDwg)
if (-not (Test-Path $srcFull)) { throw ('源图不存在: ' + $srcFull) }
if ($srcFull -eq $outFull) { throw '输出路径不能与源图相同' }
if (Test-Path $outFull) {
    if (-not $Force) { throw ('输出已存在，已拒绝覆盖: ' + $outFull + '  (如确需覆盖请加 -Force)') }
    $bak = $outFull + '.prev_' + (Get-Date -Format 'yyyyMMdd_HHmmss')
    Copy-Item $outFull $bak -Force
    Write-Host ('已备份已有成果: ' + $bak)
}
if ([string]::IsNullOrWhiteSpace($LogFile)) {
    $LogFile = Join-Path (Split-Path -Parent $outFull) ([IO.Path]::GetFileNameWithoutExtension($outFull) + '_V12执行日志.log')
}
$script:LogPath = $LogFile
if (Test-Path $LogFile) { Remove-Item $LogFile -Force }
if ([string]::IsNullOrWhiteSpace($ToolsLsp)) { $ToolsLsp = Join-Path $PSScriptRoot 'STEP5_Tools.lsp' }
if (-not (Test-Path $ToolsLsp)) { throw ('缺少 LISP 工具: ' + $ToolsLsp) }
$toolsPath = $ToolsLsp -replace '\\', '/'

$srcHash = (Get-FileHash $srcFull -Algorithm SHA256).Hash
Write-Log '======== STEP5 V1.3 开始 ========'
Write-Log ('源图: ' + $srcFull + '  SHA256=' + $srcHash)
Write-Log ('输出: ' + $outFull)
Write-Log ('LISP: ' + $toolsPath)

$outDir = Split-Path -Parent $outFull
if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Force -Path $outDir | Out-Null }
$copyFrom = $srcFull
if (-not [string]::IsNullOrWhiteSpace($RestoreFrom)) {
    $copyFrom = [IO.Path]::GetFullPath($RestoreFrom)
    if (-not (Test-Path $copyFrom)) { throw ('恢复副本不存在: ' + $copyFrom) }
    Write-Log ('使用恢复副本重建工作副本: ' + $copyFrom)
}
Copy-Item $copyFrom $outFull -Force
Write-Log ('工作副本已复制: ' + (Get-Item $outFull).Length + ' 字节')

$acad = Get-AcadApp
$pidAcad = (Get-Process acad | Select-Object -First 1).Id
$doc = $null
$origVars = @{}
$summary = New-Object System.Collections.Generic.List[object]

try {
    $n = [int]$acad.Documents.Count
    for ($i = $n - 1; $i -ge 0; $i--) {
        try { $d = $acad.Documents.Item($i); if ($d.FullName -eq $outFull) { $d.Close($false) } } catch { }
    }
    $doc = $acad.Documents.Open($outFull)
    Start-Sleep -Seconds 3
    $doc = $acad.ActiveDocument
    Write-Log ('已打开: ' + $doc.Name + ' 实体数=' + (Get-EntCount $doc))

    foreach ($v in @('RECOVERYMODE', 'FILEDIA', 'LOGFILEMODE', 'LOGFILEPATH')) {
        try { $origVars[$v] = $doc.GetVariable($v) } catch { }
    }
    Write-Log ('原始系统变量: ' + (($origVars.Keys | ForEach-Object { $_ + '=' + $origVars[$_] }) -join '; '))
    try { $doc.SetVariable('RECOVERYMODE', 0) } catch { }
    try { $doc.SetVariable('FILEDIA', 0) } catch { }
    try { $doc.SetVariable('LOGFILEMODE', 1) } catch { }
    try { $doc.SetVariable('LOGFILEPATH', (Split-Path -Parent $LogFile)) } catch { }

    # 加载工具（一次）
    Send-Queued $doc ('(load "' + $toolsPath + '") ') | Out-Null
    Start-Sleep -Milliseconds 800

    # ---- 解析目标地块（必须显式指定；-All 建议配合 -Layers 限定项目范围）
    if (-not $All -and $Handles.Count -eq 0 -and [string]::IsNullOrWhiteSpace($ParcelListFile)) {
        throw '未指定地块：请使用 -Handles "句柄1,句柄2" 或 -ParcelListFile 清单.txt 或 -All（-All 建议同时用 -Layers 限定项目范围图层）'
    }
    $want = New-Object System.Collections.Generic.List[string]
    if (-not [string]::IsNullOrWhiteSpace($ParcelListFile)) {
        if (-not (Test-Path $ParcelListFile)) { throw ('地块清单不存在: ' + $ParcelListFile) }
        foreach ($line in Get-Content $ParcelListFile) {
            $t = $line.Trim()
            if ($t -ne '' -and -not $t.StartsWith('#')) { $want.Add($t.ToUpper()) | Out-Null }
        }
    }
    foreach ($h in $Handles) { if ($h.Trim() -ne '') { $want.Add($h.Trim().ToUpper()) | Out-Null } }

    $layerSet = @()
    foreach ($l in $Layers) { if ($l.Trim() -ne '') { $layerSet += $l.Trim() } }
    $excludeSet = @()
    foreach ($l in $ExcludeLayers) { if ($l.Trim() -ne '') { $excludeSet += $l.Trim() } }
    if ($All -and $layerSet.Count -eq 0) {
        Write-Log -msg ('-All 未指定 -Layers：将处理除排除层(' + ($excludeSet -join ',') + ')外的全部闭合线，请确认范围') -level 'WARN'
    }

    $ms = $doc.ModelSpace
    $cands = New-Object System.Collections.Generic.List[object]
    for ($i = 0; $i -lt $ms.Count; $i++) {
        $e = $ms.Item($i)
        $nm = $e.ObjectName
        if ($nm -ne 'AcDbPolyline' -and $nm -ne 'AcDb2dPolyline') { continue }
        try { if (-not $e.Closed) { continue } } catch { continue }
        try { $ly = [string]$e.Layer } catch { $ly = '' }
        $h = ([string]$e.Handle).ToUpper()
        if ($want.Count -gt 0) {
            if (-not $want.Contains($h)) { continue }
        } else {
            $skip = $false
            foreach ($x in $excludeSet) { if ($ly -eq $x) { $skip = $true } }
            if ($skip) { continue }
            if ($layerSet.Count -gt 0) {
                $hit = $false
                foreach ($x in $layerSet) { if ($ly -eq $x) { $hit = $true } }
                if (-not $hit) { continue }
            }
        }
        $cands.Add([pscustomobject]@{ Handle = $h; Ent = $e }) | Out-Null
    }
    if ($want.Count -gt 0) {
        $found = @($cands | ForEach-Object { $_.Handle })
        foreach ($w in $want) {
            if (-not ($found -contains $w)) { Write-Log -msg ('指定的地块未找到或不是闭合线: ' + $w) -level 'WARN' }
        }
    }
    Write-Log ('目标地块数: ' + $cands.Count + '  句柄: ' + (($cands | ForEach-Object { $_.Handle }) -join ','))

    # ---- 预计算联合包围盒 / 现有 tk 范围（用于表格布局）
    $uMinX = [double]::MaxValue; $uMinY = [double]::MaxValue
    $uMaxX = [double]::MinValue; $uMaxY = [double]::MinValue
    $parcelInfo = @{}
    foreach ($c in $cands) {
        $v = Get-Vertices $c.Ent
        $bb = Get-BBox $v
        $parcelInfo[$c.Handle] = [pscustomobject]@{ Verts = $v; BBox = $bb; Count = $v.Count }
        if ($bb.MinX -lt $uMinX) { $uMinX = $bb.MinX }
        if ($bb.MinY -lt $uMinY) { $uMinY = $bb.MinY }
        if ($bb.MaxX -gt $uMaxX) { $uMaxX = $bb.MaxX }
        if ($bb.MaxY -gt $uMaxY) { $uMaxY = $bb.MaxY }
    }
    $tkMaxX = [double]::MinValue
    $tkMinX = [double]::MaxValue
    $tkMinY = [double]::MaxValue
    for ($i = 0; $i -lt $ms.Count; $i++) {
        $e = $ms.Item($i)
        try {
            if ($e.Layer -eq 'tk') {
                $mn = $null; $mx = $null; $e.GetBoundingBox([ref]$mn, [ref]$mx)
                if ($null -ne $mx) {
                    if ($mx[0] -gt $tkMaxX) { $tkMaxX = $mx[0] }
                    if ($null -ne $mn -and $mn[1] -lt $tkMinY) { $tkMinY = $mn[1] }
                    if ($null -ne $mn -and $mn[0] -lt $tkMinX) { $tkMinX = $mn[0] }
                }
            }
        } catch { }
    }
    $uW = $uMaxX - $uMinX; $uH = $uMaxY - $uMinY
    $gapX = [math]::Max($uW * 0.12, 12.0)
    $slotX = $uMaxX + $gapX
    if ($tkMaxX -gt [double]::MinValue -and $tkMinX -lt [double]::MaxValue) {
        $slotX = [math]::Max($tkMinX, $uMaxX + $gapX)
    }
    $gapY = [math]::Max($uH * 0.03, 3.0)
    $cursorY = $uMaxY
    if ($tkMaxX -gt [double]::MinValue -and $tkMinY -lt [double]::MaxValue) {
        $cursorY = [math]::Min($uMaxY, $tkMinY - $gapY)
    }
    Write-Log ('联合包围盒: (' + (N3 $uMinX) + ',' + (N3 $uMinY) + ')-(' + (N3 $uMaxX) + ',' + (N3 $uMaxY) + ')  表格列 X=' + (N3 $slotX))

    # ---- 逐地块处理
    $idx = 0
    foreach ($c in $cands) {
        $idx++
        $h = $c.Handle
        $phase = 'init'
        $rec = [pscustomobject]@{
            Index = $idx; Handle = $h; Area = 0.0; Verts = 0; ParcelNo = ''
            JzdCount = 0; TableEntities = 0; Status = 'FAIL'; Phase = 'init'; Error = ''; Note = ''
        }
        try {
            $ent = $doc.HandleToObject($h)
            if ($null -eq $ent) { throw '句柄对象不存在' }
            $info = $parcelInfo[$h]
            $pts = $info.Verts; $bb = $info.BBox
            $rec.Verts = $pts.Count
            try { $rec.Area = [math]::Abs([double]$ent.Area) } catch { $rec.Area = 0.0 }
            Write-Log ('---- 地块 ' + $idx + '/' + $cands.Count + ' 句柄=' + $h + ' 顶点=' + $pts.Count + ' 面积=' + (N3 $rec.Area) + ' ----')

            $phase = 'pick'
            $pick = Find-PickPoint -doc $doc -h $h -pts $pts -bb $bb
            if (-not $pick.Ok) { throw '拾取校验失败：未能唯一命中目标地块' }
            $pickX = $pick.X; $pickY = $pick.Y
            Write-Log ('拾取点: ' + (N3 $pickX) + ',' + (N3 $pickY) + '（已校验句柄）')

            $no = Get-XVal $ent 'south' 2
            $qhdm = Get-XVal $ent 'QHDM' 1
            if ($no) {
                $phase = 'state'
                $st = Test-ParcelState -doc $doc -pts $pts -no $no -qhdm $qhdm
                $rec.ParcelNo = $no
                $rec.Note = $st.Summary
                $rec.JzdCount = $st.Points
                Write-Log ('完整性判定: ' + $st.Summary)
                if ($st.Complete) {
                    $rec.Status = 'SKIP'; $rec.Phase = 'skip'
                    Write-Log ('地块 ' + $h + ' 已是完整成果（权属线+界址点+坐标表），跳过')
                    $summary.Add($rec); continue
                }
                if (-not $st.PointsOk) {
                    $rec.Status = 'INCOMPLETE'; $rec.Phase = 'points'
                    $rec.Error = ('权属线已存在但界址点不完整（' + $st.Points + '/' + $pts.Count + '），未做任何修改；请用 -RestoreFrom 从源图/备份恢复本块后重做')
                    Write-Log -msg $rec.Error -level 'WARN'
                    $summary.Add($rec); continue
                }
                if (-not $st.LabelsOk) {
                    $rec.Status = 'INCOMPLETE'; $rec.Phase = 'labels'
                    $rec.Error = '权属线/界址点已存在但点号不是 J1..Jn，未做任何修改；请人工核查该地块'
                    Write-Log -msg $rec.Error -level 'WARN'
                    $summary.Add($rec); continue
                }
                $phase = 'table-fix'
                Write-Log ('地块 ' + $h + ' 缺坐标表，执行安全补做（不重新生成界址点）')
                $tb = Ensure-Table -doc $doc -pidAcad $pidAcad -pts $pts -bb $bb -pickX $pickX -pickY $pickY -slotX $slotX -topY $cursorY
                if (-not $tb.Ok) { throw ('补做坐标表失败: ' + $tb.Error) }
                $cursorY = $tb.MinY - $gapY
                $rec.TableEntities = $tb.Entities
                $rec.Status = 'FIXED'; $rec.Phase = 'done'
                $rec.Note = $st.Summary + ' -> 已补做坐标表'
                Write-Log ('地块 ' + $h + ' 补做完成: 表格实体=' + $tb.Entities)
                $summary.Add($rec); continue
            }

            $phase = 'interior'
            $ip = Get-Interior $pts
            if ($null -eq $ip) { throw '无法计算地块内点' }
            $labelX = $ip.X; $labelY = $ip.Y
            if (-not (Test-InPoly $pts $labelX $labelY)) { throw '注记点不在多边形内' }
            Write-Log ('注记点: ' + (N3 $labelX) + ',' + (N3 $labelY))

            $phase = 'mark'
            $sp0 = Get-Space $doc 1
            if ($null -eq $sp0) { throw '无法读取模型空间' }
            $ms = $sp0.Space
            Send-Queued $doc '(c:S5MARK) ' | Out-Null
            Start-Sleep -Milliseconds 700
            $beforeSet = New-Object System.Collections.Generic.HashSet[string]
            for ($i = 0; $i -lt $ms.Count; $i++) { $beforeSet.Add(([string]$ms.Item($i).Handle).ToUpper()) | Out-Null }
            $countBefore = [int]$ms.Count

            $phase = 'convert'
            $cmd1 = 'PLTOJZLINE' + "`n" + (N3 $pickX) + ',' + (N3 $pickY) + "`n" + (N3 $labelX) + ',' + (N3 $labelY) + "`n"
            Write-Log ('发送: PLTOJZLINE 选择=' + (N3 $pickX) + ',' + (N3 $pickY) + ' 注记=' + (N3 $labelX) + ',' + (N3 $labelY))
            Send-QueuedAsync $cmd1 | Out-Null
            $res = Wait-Command -doc $doc -pidAcad $pidAcad -countBefore $countBefore -timeoutSec $TimeoutSec -dialogTitle '权属'
            Write-Log ('转换结束: done=' + $res.Done + ' dialog=' + $res.Dialog + ' 实体=' + $res.Count)

            $phase = 'verify-parcel'
            $sp1 = Get-Space $doc 1
            if ($null -eq $sp1) { throw '转换后无法读取模型空间' }
            $ms = $sp1.Space
            $ent2 = $doc.HandleToObject($h)
            if ($null -eq $ent2) { throw '转换后找不到地块对象' }
            $no = Get-XVal $ent2 'south' 2
            $qhdm = Get-XVal $ent2 'QHDM' 1
            if (-not $no) { throw '转换失败：权属线未写入宗地号' }
            $rec.ParcelNo = $no
            $expectZ = $no
            if ($qhdm) { $expectZ = $qhdm + $no }
            Write-Log ('权属线宗地号: ' + $no + '  行政区: ' + $(if ($qhdm) { $qhdm } else { '(无 QHDM)' }) + '  期望 ZDDJH: ' + $expectZ)

            $phase = 'verify-jzd'
            $newCircles = New-Object System.Collections.Generic.List[object]
            $newTexts = New-Object System.Collections.Generic.List[string]
            for ($i = 0; $i -lt $ms.Count; $i++) {
                $e = $ms.Item($i)
                $eh = ([string]$e.Handle).ToUpper()
                if ($beforeSet.Contains($eh)) { continue }
                if ($e.ObjectName -eq 'AcDbCircle' -and $e.Layer -eq 'JZP') { $newCircles.Add($e) | Out-Null }
                elseif ($e.ObjectName -eq 'AcDbText' -and $e.Layer -eq 'JZP') { $newTexts.Add([string]$e.TextString) | Out-Null }
            }
            $rec.JzdCount = $newCircles.Count
            if ($newCircles.Count -ne $pts.Count) { throw ('界址点数量不符: ' + $newCircles.Count + ' vs 顶点 ' + $pts.Count) }
            $bad = 0
            foreach ($cc in $newCircles) {
                $z = Get-XVal $cc 'ZDDJH' 1
                if (-not $z) { $bad++; continue }
                if (-not ($z -eq $expectZ -or $z.EndsWith($no))) { $bad++ }
            }
            if ($bad -gt 0) { throw ('有 ' + $bad + ' 个界址点的 ZDDJH 与本块宗地号不一致（期望 ' + $expectZ + '）') }
            $expected = @()
            for ($k = 1; $k -le $pts.Count; $k++) { $expected += ('J' + $k) }
            $sorted = @($newTexts | Sort-Object { [int]($_ -replace '[^0-9]', '') })
            if (($sorted -join ',') -ne ($expected -join ',')) { throw ('界址点点号不是 J1..J' + $pts.Count + ' : ' + ($sorted -join ',')) }
            Write-Log ('界址点: ' + $newCircles.Count + ' 个，点号 J1..J' + $pts.Count + '，ZDDJH 校验通过')

            $phase = 'table'
            $tb = Ensure-Table -doc $doc -pidAcad $pidAcad -pts $pts -bb $bb -pickX $pickX -pickY $pickY -slotX $slotX -topY $cursorY
            if (-not $tb.Ok) { throw ('坐标表处理失败: ' + $tb.Error) }
            $cursorY = $tb.MinY - $gapY
            $rec.TableEntities = $tb.Entities
            $rec.Status = 'OK'; $rec.Phase = 'done'
            $rec.Note = '权属线+界址点+坐标表 全部生成并通过校验'
            Write-Log ('地块 ' + $h + ' 完成：宗地号=' + $no + ' 界址点=' + $newCircles.Count + ' 表格实体=' + $tb.Entities)
        }
        catch {
            $rec.Status = 'FAIL'; $rec.Phase = $phase; $rec.Error = $_.Exception.Message
            Write-Log -msg ('地块 ' + $h + ' 失败（阶段 ' + $phase + '）：' + $_.Exception.Message) -level 'ERROR'
        }
        $summary.Add($rec)
    }

    $okCount = @($summary | Where-Object { $_.Status -eq 'OK' }).Count
    $fixCount = @($summary | Where-Object { $_.Status -eq 'FIXED' }).Count
    $failCount = @($summary | Where-Object { $_.Status -eq 'FAIL' }).Count
    $incCount = @($summary | Where-Object { $_.Status -eq 'INCOMPLETE' }).Count
    $skipCount = @($summary | Where-Object { $_.Status -eq 'SKIP' }).Count
    Write-Log ('汇总: 新建=' + $okCount + ' 补做=' + $fixCount + ' 跳过=' + $skipCount + ' 不完整=' + $incCount + ' 失败=' + $failCount)
    if ($incCount -gt 0) {
        $hs = @($summary | Where-Object { $_.Status -eq 'INCOMPLETE' } | ForEach-Object { $_.Handle })
        Write-Log -msg ('不完整成果需单独处理（句柄: ' + ($hs -join ',') + '）；可用 -RestoreFrom 指定干净副本后重做该图') -level 'WARN'
    }

    if (($okCount + $fixCount) -gt 0) {
        $hLeft = [S5Win2]::Find([uint32]$pidAcad, '权属')
        if ($hLeft -ne [IntPtr]::Zero) {
            Write-Log -msg '保存前发现遗留的权属区属性对话框，先行关闭' -level 'WARN'
            [S5Win2]::Enter($hLeft)
            Start-Sleep -Milliseconds 1200
        }
        try { $doc.Save() ; Write-Log ('已保存: ' + $outFull + ' ' + (Get-Item $outFull).Length + ' 字节') }
        catch { Write-Log ('保存失败: ' + $_.Exception.Message, 'ERROR') }
    } else {
        Write-Log '没有成功地块，未保存工作副本' 'WARN'
    }
}
finally {
    if ($doc -and $origVars.Count -gt 0) {
        foreach ($k in $origVars.Keys) {
            try { $doc.SetVariable($k, $origVars[$k]) } catch { }
        }
        Write-Log ('已恢复系统变量: ' + (($origVars.Keys | ForEach-Object { $_ + '=' + $origVars[$_] }) -join '; '))
    }
    $csv = Join-Path (Split-Path -Parent $LogFile) ([IO.Path]::GetFileNameWithoutExtension($OutDwg) + '_V12地块清单.csv')
    if ($summary.Count -gt 0) {
        $summary | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8
        Write-Log ('地块清单: ' + $csv)
    }
    Write-Log ('耗时: ' + [int]((Get-Date) - $t0).TotalSeconds + ' 秒')
    Write-Log '======== STEP5 V1.3 结束 ========'
}
