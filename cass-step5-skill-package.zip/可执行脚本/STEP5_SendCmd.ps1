﻿param([Parameter(Mandatory=$true)][string]$CmdFile)
$ErrorActionPreference = 'Stop'
$cmd = [IO.File]::ReadAllText($CmdFile, [Text.Encoding]::UTF8)
for ($i = 0; $i -lt 60; $i++) {
    try {
        $acad = [Runtime.InteropServices.Marshal]::GetActiveObject('AutoCAD.Application')
        $doc = $acad.ActiveDocument
        $doc.SendCommand($cmd)
        break
    } catch {
        Start-Sleep -Milliseconds 500
    }
}
Remove-Item $CmdFile -Force -ErrorAction SilentlyContinue
