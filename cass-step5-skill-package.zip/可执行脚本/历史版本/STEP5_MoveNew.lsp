
;;; ===========================================================================
;;; STEP5_MoveNew.lsp   (CASS10 / AutoCAD 2016)
;;; ֻ�ƶ��������½�����ʵ�壺��ȫ�ֱ�� *S5-MARK* ֮�󴴽���ȫ��ʵ�塣
;;;
;;; �÷���
;;;   (setq *S5-MARK* (entlast))     ; ���������֮ǰ���ñ��
;;;   ... ִ�� JZDZB ...
;;;   (c:S5MOVENEW tx ty)            ; ������ʵ���Χ�е����½��Ƶ� (tx,ty)
;;;
;;; ���������ѡ������ tk ͼ�㣩�����𣺲�������ͼ�򡢼��б��������ͼ���ʵ�塣
;;; ===========================================================================

(defun s5:entbb (e / obj mn mx a b)
  (setq obj (vlax-ename->vla-object e))
  (vla-getboundingbox obj 'mn 'mx)
  (setq a (vlax-safearray->list mn)
        b (vlax-safearray->list mx))
  (list (car a) (cadr a) (car b) (cadr b))
)

(defun c:S5MOVENEW (tx ty / ss e bb mnx mny mxx mxy i n dx dy)
  (cond
    ((null *S5-MARK*)
     (princ "\n[STEP5] *S5-MARK* not set, cancelled"))
    (T
     (setq ss (ssadd))
     (setq e (entnext *S5-MARK*))
     (while e
       (ssadd e ss)
       (setq e (entnext e))
     )
     (setq n (sslength ss))
     (if (= n 0)
       (princ "\n[STEP5] no new entity after mark, cancelled")
       (progn
         (setq i 0 mnx nil mny nil mxx nil mxy nil)
         (repeat n
           (setq bb (s5:entbb (ssname ss i)))
           (if bb
             (progn
               (if (or (null mnx) (< (car bb) mnx)) (setq mnx (car bb)))
               (if (or (null mny) (< (cadr bb) mny)) (setq mny (cadr bb)))
               (if (or (null mxx) (> (caddr bb) mxx)) (setq mxx (caddr bb)))
               (if (or (null mxy) (> (cadddr bb) mxy)) (setq mxy (cadddr bb)))
             )
           )
           (setq i (1+ i))
         )
         (setq dx (- tx mnx) dy (- ty mny))
         (command "_.MOVE" ss "" (list 0.0 0.0) (list dx dy))
         (princ (strcat "\n[STEP5] moved " (itoa n) " new entities  dx=" (rtos dx 2 4)
                        " dy=" (rtos dy 2 4) "  bbox=(" (rtos mnx 2 3) "," (rtos mny 2 3)
                        ")-(" (rtos mxx 2 3) "," (rtos mxy 2 3) ")"))
       )
     )
    )
  )
  (princ)
)

;;; �������һ�����ɵı��񣨱��֮�����ʵ�壩�İ�Χ�У���У��ʹ��
(defun c:S5NEWBB ( / ss e bb mnx mny mxx mxy i n)
  (if (and *S5-MARK* (setq e (entnext *S5-MARK*)))
    (progn
      (setq ss (ssadd))
      (while e (ssadd e ss) (setq e (entnext e)))
      (setq i 0 mnx nil mny nil mxx nil mxy nil)
      (repeat (sslength ss)
        (setq bb (s5:entbb (ssname ss i)))
        (if bb
          (progn
            (if (or (null mnx) (< (car bb) mnx)) (setq mnx (car bb)))
            (if (or (null mny) (< (cadr bb) mny)) (setq mny (cadr bb)))
            (if (or (null mxx) (> (caddr bb) mxx)) (setq mxx (caddr bb)))
            (if (or (null mxy) (> (cadddr bb) mxy)) (setq mxy (cadddr bb)))
          )
        )
        (setq i (1+ i))
      )
      (princ (strcat "\nNEWBB " (rtos mnx 2 4) " " (rtos mny 2 4) " " (rtos mxx 2 4) " " (rtos mxy 2 4)
                     " N=" (itoa (sslength ss))))
    )
    (princ "\nNEWBB none")
  )
  (princ)
)
