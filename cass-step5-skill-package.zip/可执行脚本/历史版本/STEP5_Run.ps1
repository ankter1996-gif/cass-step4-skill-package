﻿<#
================================================================================
 STEP5_Run.ps1  —  CASS10 单地块：复合线→权属线→界址点→界址点坐标表
 版本 v1.1   2026-11-13
--------------------------------------------------------------------------------
 设计原则（沿用第63批次第五步已验证的交互方案，请勿改动）：
   1) 命令处于提示状态时 AutoCAD 拒绝外部 COM 调用(RPC_E_CALL_REJECTED)，
      因此必须把“命令名 + 全部输入”一次性 SendCommand 预排队；
   2) “权属区属性”是 Qt 模态窗(Qt5QWindowIcon)，用 PostMessage 发回车确认；
   3) 坐标表生成后只移动“本次新建”的实体（标记法），不动整个 tk 图层。
--------------------------------------------------------------------------------
 输入/输出：
   -SrcDwg  源 DWG（只读，不会被修改）
   -OutDwg  工作副本 + 成果 DWG（先复制，再在其上操作并保存）
   -LogFile 执行日志（默认与成果同目录：<成果名>_执行日志.log）
--------------------------------------------------------------------------------
 用法（自动定位，推荐）：
   powershell -ExecutionPolicy Bypass -File STEP5_Run.ps1 ^
      -SrcDwg "E:\AI-Workspace\Input\单图块测试\单图块.dwg" ^
      -OutDwg "E:\AI-Workspace\Output\单图块测试\单图块_第五步测试.dwg"
 用法（复现 2026-11-13 的固定坐标测试）：
   ... -ManualGeom -PickX -4.46 -PickY 3.48 -LabelX 0 -LabelY 0 -TableX -40 -TableY 30
--------------------------------------------------------------------------------
 依赖：
   * 南方 CASS 10.1.6 For AutoCAD 2016，以 /p Cass10.1 启动并保持运行
   * Windows PowerShell 5.1（需 .NET Framework 的 Marshal.GetActiveObject）
   * STEP5_MoveNew.lsp（与本脚本同目录）
================================================================================
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$SrcDwg,
    [Parameter(Mandatory=$true)][string]$OutDwg,
    [string]$LogFile = '',
    [string]$MoveLsp = '',
    [switch]$ManualGeom,
    [double]$PickX = -4.46, [double]$PickY = 3.48,
    [double]$LabelX = 0.0,  [double]$LabelY = 0.0,
    [double]$TableX = -40.0,[double]$TableY = 30.0,
    [double]$GapRatio = 0.08,
    [int]$TimeoutSec = 300
)

$ErrorActionPreference = 'Stop'
$script:Inv = [Globalization.CultureInfo]::InvariantCulture
$script:Log = New-Object System.Collections.Generic.List[string]

function Write-Log([string]$msg) {
    $line = "[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $msg
    $script:Log.Add($line)
    Write-Host $line
}
function N3([double]$v) { return $v.ToString('0.000', $script:Inv) }

# ---------------------------------------------------------------- COM 基础
function Get-AcadApp {
    for ($i = 0; $i -lt 40; $i++) {
        try {
            $a = [Runtime.InteropServices.Marshal]::GetActiveObject('AutoCAD.Application')
            if ($a) { return $a }
        } catch { }
        Start-Sleep -Milliseconds 500
    }
    throw '未能连接到运行中的 CASS/AutoCAD，请先启动 Cass10.1 并保持运行'
}

function Send-AcadCommand([object]$doc, [string]$cmd, [int]$tries = 80) {
    for ($i = 0; $i -lt $tries; $i++) {
        try { $doc.SendCommand($cmd); return } catch { Start-Sleep -Milliseconds 400 }
    }
    throw ('SendCommand 连续失败: ' + $cmd)
}

function Wait-AcadIdle([object]$doc, [int]$seconds) {
    $deadline = (Get-Date).AddSeconds($seconds)
    while ((Get-Date) -lt $deadline) {
        try { if ([int]$doc.GetVariable('CMDACTIVE') -eq 0) { return $true } } catch { }
        Start-Sleep -Milliseconds 400
    }
    return $false
}

# ---------------------------------------------------------------- Win32 弹窗
if (-not ('S5Win' -as [type])) {
Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public class S5Win {
    public delegate bool EnumProc(IntPtr h, IntPtr l);
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr l);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
    public static IntPtr Find(uint pid, string like) {
        IntPtr res = IntPtr.Zero;
        EnumWindows((h, l) => {
            uint p; GetWindowThreadProcessId(h, out p);
            if (p == pid && IsWindowVisible(h)) {
                var t = new StringBuilder(256); GetWindowText(h, t, 256);
                if (t.ToString().Contains(like)) { res = h; return false; }
            }
            return true;
        }, IntPtr.Zero);
        return res;
    }
    public static void Enter(IntPtr h) {
        PostMessage(h, 0x0100, (IntPtr)0x0D, IntPtr.Zero);
        System.Threading.Thread.Sleep(60);
        PostMessage(h, 0x0101, (IntPtr)0x0D, IntPtr.Zero);
    }
}
"@
}

function Confirm-Dialog([int]$pid, [string]$titleLike = '权属', [int]$seconds = 30) {
    $deadline = (Get-Date).AddSeconds($seconds)
    while ((Get-Date) -lt $deadline) {
        $h = [S5Win]::Find([uint32]$pid, $titleLike)
        if ($h -ne [IntPtr]::Zero) {
            Start-Sleep -Milliseconds 800
            [S5Win]::Enter($h)
            Start-Sleep -Seconds 2
            if ([S5Win]::Find([uint32]$pid, $titleLike) -eq [IntPtr]::Zero) { return $true }
        }
        Start-Sleep -Milliseconds 400
    }
    return $false
}

# ---------------------------------------------------------------- 几何算法
function Get-PolyVertices([object]$ent) {
    $pts = New-Object System.Collections.Generic.List[object]
    $c = $ent.Coordinates
    if ($ent.ObjectName -eq 'AcDbPolyline') {
        for ($i = 0; $i + 1 -lt $c.Length; $i += 2) {
            $pts.Add([pscustomobject]@{ X = [double]$c[$i]; Y = [double]$c[$i + 1] })
        }
    } else {
        for ($i = 0; $i + 2 -lt $c.Length; $i += 3) {
            $pts.Add([pscustomobject]@{ X = [double]$c[$i]; Y = [double]$c[$i + 1] })
        }
    }
    return ,$pts
}

function Get-PolyArea($pts) {
    $s = 0.0
    for ($i = 0; $i -lt $pts.Count; $i++) {
        $j = ($i + 1) % $pts.Count
        $s += $pts[$i].X * $pts[$j].Y - $pts[$j].X * $pts[$i].Y
    }
    return [math]::Abs($s) / 2.0
}

function Test-PointInPoly($pts, [double]$x, [double]$y) {
    $inside = $false
    $n = $pts.Count
    $j = $n - 1
    for ($i = 0; $i -lt $n; $i++) {
        $xi = $pts[$i].X; $yi = $pts[$i].Y
        $xj = $pts[$j].X; $yj = $pts[$j].Y
        if ((($yi -gt $y) -ne ($yj -gt $y)) -and ($x -lt ($xj - $xi) * ($y - $yi) / ($yj - $yi) + $xi)) {
            $inside = -not $inside
        }
        $j = $i
    }
    return $inside
}

function Get-PointSegDist($pts, [double]$x, [double]$y) {
    $min = [double]::MaxValue
    $n = $pts.Count
    for ($i = 0; $i -lt $n; $i++) {
        $j = ($i + 1) % $n
        $ax = $pts[$i].X; $ay = $pts[$i].Y
        $bx = $pts[$j].X; $by = $pts[$j].Y
        $dx = $bx - $ax; $dy = $by - $ay
        $len2 = $dx * $dx + $dy * $dy
        $t = 0.0
        if ($len2 -gt 0) { $t = (($x - $ax) * $dx + ($y - $ay) * $dy) / $len2; if ($t -lt 0) { $t = 0 } elseif ($t -gt 1) { $t = 1 } }
        $px = $ax + $t * $dx; $py = $ay + $t * $dy
        $d = [math]::Sqrt(($x - $px) * ($x - $px) + ($y - $py) * ($y - $py))
        if ($d -lt $min) { $min = $d }
    }
    return $min
}

# 宗地号注记位置：优先面积质心；凹多边形质心在外时，网格搜索“离边界最远的内部点”
function Get-InteriorPoint($pts) {
    $a = 0.0; $cx = 0.0; $cy = 0.0
    $n = $pts.Count
    for ($i = 0; $i -lt $n; $i++) {
        $j = ($i + 1) % $n
        $cross = $pts[$i].X * $pts[$j].Y - $pts[$j].X * $pts[$i].Y
        $a += $cross
        $cx += ($pts[$i].X + $pts[$j].X) * $cross
        $cy += ($pts[$i].Y + $pts[$j].Y) * $cross
    }
    $a = $a / 2.0
    if ([math]::Abs($a) -gt 1e-9) {
        $cx = $cx / (6.0 * $a); $cy = $cy / (6.0 * $a)
        if (Test-PointInPoly $pts $cx $cy) { return [pscustomobject]@{ X = $cx; Y = $cy } }
    }
    $xs = $pts | ForEach-Object { $_.X }
    $ys = $pts | ForEach-Object { $_.Y }
    $minx = ($xs | Measure-Object -Minimum).Minimum
    $maxx = ($xs | Measure-Object -Maximum).Maximum
    $miny = ($ys | Measure-Object -Minimum).Minimum
    $maxy = ($ys | Measure-Object -Maximum).Maximum
    $best = $null; $bestD = -1.0
    $steps = 60
    for ($ix = 1; $ix -lt $steps; $ix++) {
        for ($iy = 1; $iy -lt $steps; $iy++) {
            $x = $minx + ($maxx - $minx) * $ix / $steps
            $y = $miny + ($maxy - $miny) * $iy / $steps
            if (Test-PointInPoly $pts $x $y) {
                $d = Get-PointSegDist $pts $x $y
                if ($d -gt $bestD) { $bestD = $d; $best = [pscustomobject]@{ X = $x; Y = $y } }
            }
        }
    }
    if ($best) { return $best }
    # 兜底：第一个顶点向多边形内部微移
    return [pscustomobject]@{ X = (($pts[0].X + $pts[1].X) / 2.0); Y = (($pts[0].Y + $pts[1].Y) / 2.0) }
}

# ================================================================ 主流程
$t0 = Get-Date
if ([string]::IsNullOrWhiteSpace($LogFile)) {
    $LogFile = Join-Path (Split-Path -Parent $OutDwg) ([IO.Path]::GetFileNameWithoutExtension($OutDwg) + '_执行日志.log')
}
if ([string]::IsNullOrWhiteSpace($MoveLsp)) {
    $MoveLsp = Join-Path $PSScriptRoot 'STEP5_MoveNew.lsp'
}

Write-Log '==== STEP5 v1.1 开始 ===='
Write-Log ('源图    : ' + $SrcDwg)
Write-Log ('工作副本: ' + $OutDwg)
Write-Log ('日志    : ' + $LogFile)
Write-Log ('几何模式: ' + $(if ($ManualGeom) { '手动固定坐标' } else { '自动计算' }))

$srcHash = (Get-FileHash $SrcDwg -Algorithm SHA256).Hash
Write-Log ('源图 SHA256: ' + $srcHash)

$outDir = Split-Path -Parent $OutDwg
if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Force -Path $outDir | Out-Null }
Copy-Item $SrcDwg $OutDwg -Force
Write-Log ('已复制工作副本: ' + (Get-Item $OutDwg).Length + ' 字节')

$acad = Get-AcadApp
$acadName = ''
try { $acadName = [string]$acad.Name } catch { }
Write-Log ('已连接: ' + $acadName + ' 版本=' + [string]$acad.Version)
$pidAcad = (Get-Process acad | Select-Object -First 1).Id

$n = [int]$acad.Documents.Count
for ($i = $n - 1; $i -ge 0; $i--) {
    try {
        $d = $acad.Documents.Item($i)
        if ($d.FullName -eq $OutDwg) { $d.Close($false) }
    } catch { }
}
$doc = $acad.Documents.Open($OutDwg)
Start-Sleep -Seconds 3
$doc = $acad.ActiveDocument
Write-Log ('已打开: ' + $doc.FullName + '  实体数=' + [int]$doc.ModelSpace.Count)

foreach ($v in @(@('RECOVERYMODE', 0), @('FILEDIA', 0), @('LOGFILEMODE', 1), @('LOGFILEPATH', (Split-Path -Parent $LogFile)))) {
    try { $doc.SetVariable($v[0], $v[1]) } catch { Write-Log ('系统变量 ' + $v[0] + ' 设置失败(可忽略)') }
}

# ---- 找目标地块（闭合复合线/权属线，排除界址点层与表格层）
$ms = $doc.ModelSpace
$target = $null; $bestArea = -1.0
for ($i = 0; $i -lt $ms.Count; $i++) {
    $e = $ms.Item($i)
    $nm = $e.ObjectName
    if ($nm -ne 'AcDbPolyline' -and $nm -ne 'AcDb2dPolyline') { continue }
    try { if (-not $e.Closed) { continue } } catch { continue }
    try { $ly = [string]$e.Layer } catch { $ly = '' }
    if ($ly -eq 'JZP' -or $ly -eq 'tk') { continue }
    try { $ar = [double]$e.Area } catch { $ar = 0.0 }
    if ($ar -gt $bestArea) { $bestArea = $ar; $target = $e }
}
if (-not $target) { throw '未找到可用的闭合复合线/权属线' }
$verts = Get-PolyVertices $target
$vcount = $verts.Count
Write-Log ('目标地块: 句柄=' + $target.Handle + ' 图层=' + $target.Layer + ' 顶点=' + $vcount + ' 面积=' + (N3 $bestArea))

$xs = $verts | ForEach-Object { $_.X }
$ys = $verts | ForEach-Object { $_.Y }
$minx = ($xs | Measure-Object -Minimum).Minimum
$maxx = ($xs | Measure-Object -Maximum).Maximum
$miny = ($ys | Measure-Object -Minimum).Minimum
$maxy = ($ys | Measure-Object -Maximum).Maximum
$pw = $maxx - $minx; $ph = $maxy - $miny
Write-Log ('包围盒: (' + (N3 $minx) + ',' + (N3 $miny) + ')-(' + (N3 $maxx) + ',' + (N3 $maxy) + ')  宽=' + (N3 $pw) + ' 高=' + (N3 $ph))

if ($ManualGeom) {
    $pickX = $PickX; $pickY = $PickY
    $labelX = $LabelX; $labelY = $LabelY
    $tabX = $TableX; $tabY = $TableY
} else {
    # 选择点：最长边中点（必然落在实体上，且远离顶点/界址点圆圈）
    $p1 = $null; $p2 = $null; $maxLen = -1.0
    for ($i = 0; $i -lt $vcount; $i++) {
        $j = ($i + 1) % $vcount
        $dx = $verts[$j].X - $verts[$i].X; $dy = $verts[$j].Y - $verts[$i].Y
        $L = [math]::Sqrt($dx * $dx + $dy * $dy)
        if ($L -gt $maxLen) { $maxLen = $L; $p1 = $verts[$i]; $p2 = $verts[$j] }
    }
    $pickX = ($p1.X + $p2.X) / 2.0; $pickY = ($p1.Y + $p2.Y) / 2.0
    $ip = Get-InteriorPoint $verts
    $labelX = $ip.X; $labelY = $ip.Y
    # 表格暂定点：地块上方一个图幅高度处，生成后按实际包围盒精确对齐
    $tabX = $minx; $tabY = $maxy + $ph
}
Write-Log ('选择点   : ' + (N3 $pickX) + ',' + (N3 $pickY))
Write-Log ('注记位置 : ' + (N3 $labelX) + ',' + (N3 $labelY))
Write-Log ('表格暂定点: ' + (N3 $tabX) + ',' + (N3 $tabY))

# ---- 阶段一：复合线 -> 权属线（PLTOJZLINE）
$before1 = [int]$ms.Count
$cmd1 = 'PLTOJZLINE' + "`n" + (N3 $pickX) + ',' + (N3 $pickY) + "`n" + (N3 $labelX) + ',' + (N3 $labelY) + "`n"
Write-Log ('发送排队命令: PLTOJZLINE / 选择点 / 注记点')
Send-AcadCommand $doc $cmd1
$dlgOk = Confirm-Dialog $pidAcad '权属' 40
Write-Log ('权属区属性对话框回车确认: ' + $dlgOk)
$idle1 = Wait-AcadIdle $doc 90
$after1 = [int]$ms.Count
Write-Log ('阶段一完成: 实体 ' + $before1 + ' -> ' + $after1 + '  idle=' + $idle1)
# 复合线是“原地转换”：不新增多段线，只新增 圆圈+符号块+点号 共 3*顶点数
$expect1 = 3 * $vcount
if (($after1 - $before1) -lt $expect1) { throw ('权属线/界址点生成数量不足，预期 +' + $expect1 + '，实际 +' + ($after1 - $before1)) }

# 统计界址点
$jzdCount = 0
for ($i = 0; $i -lt $ms.Count; $i++) {
    $e = $ms.Item($i)
    try {
        if ($e.Layer -eq 'JZP' -and $e.ObjectName -eq 'AcDbCircle') { $jzdCount++ }
    } catch { }
}
Write-Log ('界址点圆圈数量: ' + $jzdCount + '（应等于顶点数 ' + $vcount + '）')
if ($jzdCount -ne $vcount) { throw ('界址点数量与顶点数不一致: ' + $jzdCount + ' vs ' + $vcount) }

# ---- 阶段二：界址点坐标表（JZDZB）
Send-AcadCommand $doc '(setq *S5-MARK* (entlast)) '
Start-Sleep -Milliseconds 800
$before2 = [int]$ms.Count
$cmd2 = 'JZDZB' + "`n" + (N3 $tabX) + ',' + (N3 $tabY) + "`n" + "`n" + (N3 $pickX) + ',' + (N3 $pickY) + "`n"
Write-Log ('发送排队命令: JZDZB / 表格点 / 默认定点方法 / 选择宗地')
Send-AcadCommand $doc $cmd2
Start-Sleep -Seconds 2
$deadline2 = (Get-Date).AddSeconds(120)
while ((Get-Date) -lt $deadline2) {
    if ([int]$ms.Count -gt $before2) { break }
    Start-Sleep -Milliseconds 500
}
$idle2 = Wait-AcadIdle $doc 60
$after2 = [int]$ms.Count
Write-Log ('阶段二完成: 实体 ' + $before2 + ' -> ' + $after2 + '  idle=' + $idle2)
if ($after2 -le $before2) { throw '界址点坐标表未生成' }

# ---- 只移动本次新建的表格实体：左下角对齐 (minx, maxy+gap)
$gap = [math]::Max($ph * $GapRatio, 1.0)
$tgtX = $minx
$tgtY = $maxy + $gap
$cmd3 = '(load "' + ($MoveLsp -replace '\\', '/') + '") (c:S5MOVENEW ' + (N3 $tgtX) + ' ' + (N3 $tgtY) + ') '
Write-Log ('移动本次表格至左下角: ' + (N3 $tgtX) + ',' + (N3 $tgtY) + ' (gap=' + (N3 $gap) + ')')
Send-AcadCommand $doc $cmd3
Start-Sleep -Seconds 1
Wait-AcadIdle $doc 60 | Out-Null

# ---- 校验表格包围盒
$newStart = $before2
$tminx = [double]::MaxValue; $tminy = [double]::MaxValue
$tmaxx = [double]::MinValue; $tmaxy = [double]::MinValue
for ($i = $newStart; $i -lt $ms.Count; $i++) {
    $e = $ms.Item($i)
    try {
        $mn = $null; $mx = $null
        $e.GetBoundingBox([ref]$mn, [ref]$mx)
        if ($null -ne $mn) {
            if ($mn[0] -lt $tminx) { $tminx = $mn[0] }
            if ($mn[1] -lt $tminy) { $tminy = $mn[1] }
            if ($mx[0] -gt $tmaxx) { $tmaxx = $mx[0] }
            if ($mx[1] -gt $tmaxy) { $tmaxy = $mx[1] }
        }
    } catch { }
}
Write-Log ('表格包围盒: (' + (N3 $tminx) + ',' + (N3 $tminy) + ')-(' + (N3 $tmaxx) + ',' + (N3 $tmaxy) + ')')
$devX = [math]::Abs($tminx - $tgtX); $devY = [math]::Abs($tminy - $tgtY)
Write-Log ('对齐偏差: dx=' + (N3 $devX) + ' dy=' + (N3 $devY))

# ---- 保存 + 日志
$doc.Save()
Start-Sleep -Seconds 2
Write-Log ('已保存: ' + $doc.FullName + '  ' + (Get-Item $OutDwg).Length + ' 字节')
$srcHash2 = (Get-FileHash $SrcDwg -Algorithm SHA256).Hash
Write-Log ('源图 SHA256(后): ' + $srcHash2 + '  未被修改=' + ($srcHash2 -eq $srcHash))
Write-Log ('耗时: ' + [int]((Get-Date) - $t0).TotalSeconds + ' 秒')

$script:Log | Set-Content -Path $LogFile -Encoding UTF8
Write-Host ''
Write-Host ('完成。成果: ' + $OutDwg)
Write-Host ('日志: ' + $LogFile)
