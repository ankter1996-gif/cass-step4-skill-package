﻿<#
================================================================================
 STEP5_Run_V1.2.ps1 — CASS10 单/多地块：权属线 + 界址点 + 界址点坐标表
 版本 V1.2   2026-11-13
--------------------------------------------------------------------------------
 相对 V1.1 的改动（按用户 9 条要求）：
   1. 目标地块：支持 -Handles / -ParcelListFile / -All，不再“取最大面积”；
      每个地块独立转换、独立 J1 起编号、独立一张坐标表。
   2. 界址点检查：只核对本轮新增的 JZP 圆圈，且其 ZDDJH 必须等于当前权属线宗地号。
   3. 坐标表移动：先 S5MARK 再 JZDZB；只移动标记之后新建的实体；移动后核对包围盒。
   4. 命令状态：以 CMDACTIVE + 实体数 + 对话框状态判定完成；COM 拒绝调用时受限重试，
      不因读取 Count 失败而中断。
   5. 系统变量：记录 RECOVERYMODE/FILEDIA/LOGFILEMODE/LOGFILEPATH 原值，finally 恢复。
   6. 错误处理：逐地块 try/catch，记录阶段/原因；失败地块不写入成功汇总。
   7. 文件安全：源图只读；输出已存在时默认拒绝覆盖（-Force 才覆盖）；已转换地块跳过。
   8. 坐标自适应：最长边中点 + 拾取校验 + 质心/网格内点 + 按实测包围盒摆放表格；
      表格统一放在所有地块右侧并按高度堆叠，避免与地块/其它表格重叠。
   9. 宗地编号：不修改 CASS 全局库；记录实际生成的宗地号（权属线 south 扩展数据）。
--------------------------------------------------------------------------------
 依赖：CASS 10.1.6 For AutoCAD 2016（/p Cass10.1 常驻）、Windows PowerShell 5.1、
       STEP5_Tools.lsp（同目录）
================================================================================
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$SrcDwg,
    [Parameter(Mandatory=$true)][string]$OutDwg,
    [string]$LogFile = '',
    [string[]]$Handles = @(),
    [string]$ParcelListFile = '',
    [switch]$All,
    [switch]$Force,
    [string]$ToolsLsp = '',
    [double]$GapRatio = 0.08,
    [int]$TimeoutSec = 120
)

$ErrorActionPreference = 'Stop'
$script:Inv = [Globalization.CultureInfo]::InvariantCulture
$script:LogPath = $null
$script:LogLines = New-Object System.Collections.Generic.List[string]
$script:Utf8 = New-Object System.Text.UTF8Encoding($true)

function Write-Log([string]$msg, [string]$level = 'INFO') {
    $line = "[{0}] [{1}] {2}" -f (Get-Date -Format 'HH:mm:ss'), $level, $msg
    $script:LogLines.Add($line)
    Write-Host $line
    if ($script:LogPath) {
        try { [IO.File]::AppendAllText($script:LogPath, $line + "`r`n", $script:Utf8) } catch { }
    }
}
function N3([double]$v) { return $v.ToString('0.000', $script:Inv) }

# ------------------------------------------------------------------ COM 基础
function Get-AcadApp {
    for ($i = 0; $i -lt 40; $i++) {
        try {
            $a = [Runtime.InteropServices.Marshal]::GetActiveObject('AutoCAD.Application')
            if ($a) { return $a }
        } catch { }
        Start-Sleep -Milliseconds 500
    }
    throw '未能连接到运行中的 CASS/AutoCAD'
}

function Try-Com([scriptblock]$sb, [int]$tries = 30, [int]$delayMs = 300) {
    for ($i = 0; $i -lt $tries; $i++) {
        try { return (& $sb) } catch { Start-Sleep -Milliseconds $delayMs }
    }
    return $null
}

function Get-CmdActive([object]$doc) {
    # 返回 0/1，读取被拒绝时返回 $null（视为忙）
    try { return [int]$doc.GetVariable('CMDACTIVE') } catch { return $null }
}

function Get-EntCount([object]$doc) {
    # ModelSpace.Count 偶发返回 0（图形重生成中），重试以避免误判
    for ($k = 0; $k -lt 8; $k++) {
        try { $c = [int]$doc.ModelSpace.Count; if ($c -gt 0) { return $c } } catch { }
        Start-Sleep -Milliseconds 200
    }
    try { return [int]$doc.ModelSpace.Count } catch { return -1 }
}

function Get-Space([object]$doc, [int]$minCount = 1) {
    for ($k = 0; $k -lt 25; $k++) {
        try { $sp = $doc.ModelSpace; $c = [int]$sp.Count; if ($c -ge $minCount) { return @{ Space = $sp; Count = $c } } } catch { }
        Start-Sleep -Milliseconds 300
    }
    return $null
}

# ------------------------------------------------------------------ Win32
if (-not ('S5Win2' -as [type])) {
Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public class S5Win2 {
    public delegate bool EnumProc(IntPtr h, IntPtr l);
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr l);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
    public static IntPtr Find(uint pid, string like) {
        IntPtr res = IntPtr.Zero;
        EnumWindows((h, l) => {
            uint p; GetWindowThreadProcessId(h, out p);
            if (p == pid && IsWindowVisible(h)) {
                var t = new StringBuilder(256); GetWindowText(h, t, 256);
                if (t.ToString().Contains(like)) { res = h; return false; }
            }
            return true;
        }, IntPtr.Zero);
        return res;
    }
    public static void Enter(IntPtr h) {
        PostMessage(h, 0x0100, (IntPtr)0x0D, IntPtr.Zero);
        System.Threading.Thread.Sleep(60);
        PostMessage(h, 0x0101, (IntPtr)0x0D, IntPtr.Zero);
    }
}
"@
}

function Wait-Command {
    param([object]$doc, [int]$pidAcad, [int]$countBefore, [int]$timeoutSec, [string]$dialogTitle = '')
    $startTime = Get-Date
    $deadline = $startTime.AddSeconds($timeoutSec)
    $sawActive = $false
    $idle = 0
    $confirmed = $false
    while ((Get-Date) -lt $deadline) {
        if ($dialogTitle -ne '') {
            $h = [S5Win2]::Find([uint32]$pidAcad, $dialogTitle)
            if ($h -ne [IntPtr]::Zero) {
                Start-Sleep -Milliseconds 700
                [S5Win2]::Enter($h)
                Start-Sleep -Milliseconds 1500
                $confirmed = $true
                $idle = 0
                continue
            }
        }
        $act = Get-CmdActive $doc
        $cnt = Get-EntCount $doc
        if ($act -eq 1 -or $null -eq $act) { $sawActive = $true; $idle = 0 }
        elseif ($cnt -gt $countBefore) { $sawActive = $true; return @{ Done = $true; Dialog = $confirmed; Count = $cnt } }
        else {
            if ($sawActive) {
                if ($dialogTitle -ne '' -and -not $confirmed) { return @{ Done = $false; Dialog = $false; Count = $cnt } }
                return @{ Done = $true; Dialog = $confirmed; Count = $cnt }
            }
            # 启动宽限期：异步发送进程可能还没把命令送进来
            if (((Get-Date) - $startTime).TotalSeconds -gt 12) {
                $idle++
                if ($idle -gt 15) { return @{ Done = $false; Dialog = $confirmed; Count = $cnt } }
            }
        }
        Start-Sleep -Milliseconds 350
    }
    return @{ Done = $false; Dialog = $confirmed; Count = (Get-EntCount $doc) }
}

function Send-Queued([object]$doc, [string]$cmd) {
    for ($i = 0; $i -lt 40; $i++) {
        try { $doc.SendCommand($cmd); return $true } catch { Start-Sleep -Milliseconds 400 }
    }
    return $false
}

# 异步发送（用于会弹出模态框的命令：SendCommand 会被对话框阻塞，必须在独立进程中执行）
function Send-QueuedAsync([string]$cmd) {
    $f = Join-Path $env:TEMP ('s5cmd_' + [guid]::NewGuid().ToString('N') + '.txt')
    [IO.File]::WriteAllText($f, $cmd, (New-Object Text.UTF8Encoding($false)))
    $helper = Join-Path $PSScriptRoot 'STEP5_SendCmd.ps1'
    Start-Process powershell -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $helper + '"'),'-CmdFile',('"' + $f + '"') -WindowStyle Hidden | Out-Null
    return $f
}

# ------------------------------------------------------------------ 几何
function Get-Vertices([object]$ent) {
    $pts = New-Object System.Collections.Generic.List[object]
    $c = $ent.Coordinates
    if ($ent.ObjectName -eq 'AcDbPolyline') {
        for ($i = 0; $i + 1 -lt $c.Length; $i += 2) { $pts.Add([pscustomobject]@{ X = [double]$c[$i]; Y = [double]$c[$i + 1] }) }
    } else {
        for ($i = 0; $i + 2 -lt $c.Length; $i += 3) { $pts.Add([pscustomobject]@{ X = [double]$c[$i]; Y = [double]$c[$i + 1] }) }
    }
    return ,$pts
}
function Get-BBox($pts) {
    $xs = $pts | ForEach-Object { $_.X }
    $ys = $pts | ForEach-Object { $_.Y }
    return [pscustomobject]@{
        MinX = ($xs | Measure-Object -Minimum).Minimum
        MaxX = ($xs | Measure-Object -Maximum).Maximum
        MinY = ($ys | Measure-Object -Minimum).Minimum
        MaxY = ($ys | Measure-Object -Maximum).Maximum
    }
}
function Test-InPoly($pts, [double]$x, [double]$y) {
    $inside = $false; $n = $pts.Count; $j = $n - 1
    for ($i = 0; $i -lt $n; $i++) {
        $xi = $pts[$i].X; $yi = $pts[$i].Y; $xj = $pts[$j].X; $yj = $pts[$j].Y
        if ((($yi -gt $y) -ne ($yj -gt $y)) -and ($x -lt ($xj - $xi) * ($y - $yi) / ($yj - $yi) + $xi)) { $inside = -not $inside }
        $j = $i
    }
    return $inside
}
function Get-SegDist($pts, [double]$x, [double]$y) {
    $min = [double]::MaxValue; $n = $pts.Count
    for ($i = 0; $i -lt $n; $i++) {
        $j = ($i + 1) % $n
        $ax = $pts[$i].X; $ay = $pts[$i].Y; $bx = $pts[$j].X; $by = $pts[$j].Y
        $dx = $bx - $ax; $dy = $by - $ay; $l2 = $dx * $dx + $dy * $dy
        $t = 0.0
        if ($l2 -gt 0) { $t = (($x - $ax) * $dx + ($y - $ay) * $dy) / $l2; if ($t -lt 0) { $t = 0 } elseif ($t -gt 1) { $t = 1 } }
        $px = $ax + $t * $dx; $py = $ay + $t * $dy
        $d = [math]::Sqrt(($x - $px) * ($x - $px) + ($y - $py) * ($y - $py))
        if ($d -lt $min) { $min = $d }
    }
    return $min
}
function Get-Interior($pts) {
    $a = 0.0; $cx = 0.0; $cy = 0.0; $n = $pts.Count
    for ($i = 0; $i -lt $n; $i++) {
        $j = ($i + 1) % $n
        $cr = $pts[$i].X * $pts[$j].Y - $pts[$j].X * $pts[$i].Y
        $a += $cr; $cx += ($pts[$i].X + $pts[$j].X) * $cr; $cy += ($pts[$i].Y + $pts[$j].Y) * $cr
    }
    $a = $a / 2.0
    $bb0 = Get-BBox $pts
    $need = [math]::Max([math]::Min(($bb0.MaxX - $bb0.MinX), ($bb0.MaxY - $bb0.MinY)) * 0.06, 0.5)
    if ([math]::Abs($a) -gt 1e-9) {
        $cx = $cx / (6.0 * $a); $cy = $cy / (6.0 * $a)
        # 质心在多边形内且离边界足够远才采用（凹多边形质心可能贴近缺口边）
        if ((Test-InPoly $pts $cx $cy) -and ((Get-SegDist $pts $cx $cy) -ge $need)) {
            return [pscustomobject]@{ X = $cx; Y = $cy }
        }
    }
    $bb = Get-BBox $pts
    $best = $null; $bd = -1.0
    $steps = 60
    for ($ix = 1; $ix -lt $steps; $ix++) {
        for ($iy = 1; $iy -lt $steps; $iy++) {
            $x = $bb.MinX + ($bb.MaxX - $bb.MinX) * $ix / $steps
            $y = $bb.MinY + ($bb.MaxY - $bb.MinY) * $iy / $steps
            if (Test-InPoly $pts $x $y) {
                $d = Get-SegDist $pts $x $y
                if ($d -gt $bd) { $bd = $d; $best = [pscustomobject]@{ X = $x; Y = $y } }
            }
        }
    }
    return $best
}
function Get-EdgeCandidates($pts) {
    $list = New-Object System.Collections.Generic.List[object]
    $n = $pts.Count
    for ($i = 0; $i -lt $n; $i++) {
        $j = ($i + 1) % $n
        $dx = $pts[$j].X - $pts[$i].X; $dy = $pts[$j].Y - $pts[$i].Y
        $L = [math]::Sqrt($dx * $dx + $dy * $dy)
        $list.Add([pscustomobject]@{ L = $L; X = ($pts[$i].X + $pts[$j].X) / 2.0; Y = ($pts[$i].Y + $pts[$j].Y) / 2.0 })
    }
    return ,($list | Sort-Object -Property L -Descending)
}
function Zoom-Window([object]$doc, [double]$x1, [double]$y1, [double]$x2, [double]$y2) {
    $cmd = '(command "_.ZOOM" "_W" (list ' + (N3 $x1) + ' ' + (N3 $y1) + ') (list ' + (N3 $x2) + ' ' + (N3 $y2) + ')) '
    Send-Queued $doc $cmd | Out-Null
    Start-Sleep -Milliseconds 900
}

# ------------------------------------------------------------------ XData
function Get-XVal([object]$ent, [string]$app, [int]$index) {
    $xt = $null; $xv = $null
    try { $ent.GetXData($app, [ref]$xt, [ref]$xv) } catch { return $null }
    if ($null -eq $xv) { return $null }
    if ($index -lt 0 -or $index -ge $xv.Length) { return $null }
    return [string]$xv[$index]
}

# ------------------------------------------------------------------ 主流程
$t0 = Get-Date
$srcFull = [IO.Path]::GetFullPath($SrcDwg)
$outFull = [IO.Path]::GetFullPath($OutDwg)
if (-not (Test-Path $srcFull)) { throw ('源图不存在: ' + $srcFull) }
if ($srcFull -eq $outFull) { throw '输出路径不能与源图相同' }
if (Test-Path $outFull) {
    if (-not $Force) { throw ('输出已存在，已拒绝覆盖: ' + $outFull + '  (如确需覆盖请加 -Force)') }
    $bak = $outFull + '.prev_' + (Get-Date -Format 'yyyyMMdd_HHmmss')
    Copy-Item $outFull $bak -Force
    Write-Host ('已备份已有成果: ' + $bak)
}
if ([string]::IsNullOrWhiteSpace($LogFile)) {
    $LogFile = Join-Path (Split-Path -Parent $outFull) ([IO.Path]::GetFileNameWithoutExtension($outFull) + '_V12执行日志.log')
}
$script:LogPath = $LogFile
if (Test-Path $LogFile) { Remove-Item $LogFile -Force }
if ([string]::IsNullOrWhiteSpace($ToolsLsp)) { $ToolsLsp = Join-Path $PSScriptRoot 'STEP5_Tools.lsp' }
if (-not (Test-Path $ToolsLsp)) { throw ('缺少 LISP 工具: ' + $ToolsLsp) }
$toolsPath = $ToolsLsp -replace '\\', '/'

$srcHash = (Get-FileHash $srcFull -Algorithm SHA256).Hash
Write-Log '======== STEP5 V1.2 开始 ========'
Write-Log ('源图: ' + $srcFull + '  SHA256=' + $srcHash)
Write-Log ('输出: ' + $outFull)
Write-Log ('LISP: ' + $toolsPath)

$outDir = Split-Path -Parent $outFull
if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Force -Path $outDir | Out-Null }
Copy-Item $srcFull $outFull -Force
Write-Log ('工作副本已复制: ' + (Get-Item $outFull).Length + ' 字节')

$acad = Get-AcadApp
$pidAcad = (Get-Process acad | Select-Object -First 1).Id
$doc = $null
$origVars = @{}
$summary = New-Object System.Collections.Generic.List[object]

try {
    $n = [int]$acad.Documents.Count
    for ($i = $n - 1; $i -ge 0; $i--) {
        try { $d = $acad.Documents.Item($i); if ($d.FullName -eq $outFull) { $d.Close($false) } } catch { }
    }
    $doc = $acad.Documents.Open($outFull)
    Start-Sleep -Seconds 3
    $doc = $acad.ActiveDocument
    Write-Log ('已打开: ' + $doc.Name + ' 实体数=' + (Get-EntCount $doc))

    foreach ($v in @('RECOVERYMODE', 'FILEDIA', 'LOGFILEMODE', 'LOGFILEPATH')) {
        try { $origVars[$v] = $doc.GetVariable($v) } catch { }
    }
    Write-Log ('原始系统变量: ' + (($origVars.Keys | ForEach-Object { $_ + '=' + $origVars[$_] }) -join '; '))
    try { $doc.SetVariable('RECOVERYMODE', 0) } catch { }
    try { $doc.SetVariable('FILEDIA', 0) } catch { }
    try { $doc.SetVariable('LOGFILEMODE', 1) } catch { }
    try { $doc.SetVariable('LOGFILEPATH', (Split-Path -Parent $LogFile)) } catch { }

    # 加载工具（一次）
    Send-Queued $doc ('(load "' + $toolsPath + '") ') | Out-Null
    Start-Sleep -Milliseconds 800

    # ---- 解析目标地块清单
    $want = New-Object System.Collections.Generic.List[string]
    if (-not [string]::IsNullOrWhiteSpace($ParcelListFile)) {
        foreach ($line in Get-Content $ParcelListFile) { $t = $line.Trim(); if ($t -ne '' -and -not $t.StartsWith('#')) { $want.Add($t.ToUpper()) } }
    }
    foreach ($h in $Handles) { if ($h.Trim() -ne '') { $want.Add($h.Trim().ToUpper()) } }

    $ms = $doc.ModelSpace
    $cands = New-Object System.Collections.Generic.List[object]
    for ($i = 0; $i -lt $ms.Count; $i++) {
        $e = $ms.Item($i)
        $nm = $e.ObjectName
        if ($nm -ne 'AcDbPolyline' -and $nm -ne 'AcDb2dPolyline') { continue }
        try { if (-not $e.Closed) { continue } } catch { continue }
        try { $ly = [string]$e.Layer } catch { $ly = '' }
        if ($ly -eq 'JZP' -or $ly -eq 'tk') { continue }
        $h = ([string]$e.Handle).ToUpper()
        if ($want.Count -gt 0 -and -not $want.Contains($h)) { continue }
        $cands.Add([pscustomobject]@{ Handle = $h; Ent = $e })
    }
    if ($cands.Count -eq 0) { throw '未找到符合条件的目标地块（闭合复合线/权属线）' }
    $cands = @($cands | Sort-Object -Property Handle)
    Write-Log ('目标地块数: ' + $cands.Count + '  句柄: ' + (($cands | ForEach-Object { $_.Handle }) -join ','))

    # ---- 预计算联合包围盒 / 现有 tk 范围（用于表格布局）
    $uMinX = [double]::MaxValue; $uMinY = [double]::MaxValue
    $uMaxX = [double]::MinValue; $uMaxY = [double]::MinValue
    $parcelInfo = @{}
    foreach ($c in $cands) {
        $v = Get-Vertices $c.Ent
        $bb = Get-BBox $v
        $parcelInfo[$c.Handle] = [pscustomobject]@{ Verts = $v; BBox = $bb; Count = $v.Count }
        if ($bb.MinX -lt $uMinX) { $uMinX = $bb.MinX }
        if ($bb.MinY -lt $uMinY) { $uMinY = $bb.MinY }
        if ($bb.MaxX -gt $uMaxX) { $uMaxX = $bb.MaxX }
        if ($bb.MaxY -gt $uMaxY) { $uMaxY = $bb.MaxY }
    }
    $tkMaxX = [double]::MinValue
    for ($i = 0; $i -lt $ms.Count; $i++) {
        $e = $ms.Item($i)
        try {
            if ($e.Layer -eq 'tk') {
                $mn = $null; $mx = $null; $e.GetBoundingBox([ref]$mn, [ref]$mx)
                if ($null -ne $mx -and $mx[0] -gt $tkMaxX) { $tkMaxX = $mx[0] }
            }
        } catch { }
    }
    $uW = $uMaxX - $uMinX; $uH = $uMaxY - $uMinY
    $gapX = [math]::Max($uW * 0.12, 12.0)
    $slotX = [math]::Max($uMaxX + $gapX, $(if ($tkMaxX -gt [double]::MinValue) { $tkMaxX + $gapX } else { $uMaxX + $gapX }))
    $cursorY = $uMaxY
    $gapY = [math]::Max($uH * 0.03, 3.0)
    Write-Log ('联合包围盒: (' + (N3 $uMinX) + ',' + (N3 $uMinY) + ')-(' + (N3 $uMaxX) + ',' + (N3 $uMaxY) + ')  表格列 X=' + (N3 $slotX))

    # ---- 逐地块处理
    $idx = 0
    foreach ($c in $cands) {
        $idx++
        $h = $c.Handle
        $phase = 'init'
        $rec = [pscustomobject]@{
            Index = $idx; Handle = $h; Area = 0.0; Verts = 0; ParcelNo = ''
            JzdCount = 0; TableEntities = 0; Status = 'FAIL'; Phase = 'init'; Error = ''
        }
        try {
            $phase = 'open'
            $ent = $doc.HandleToObject($h)
            if ($null -eq $ent) { throw '句柄对象不存在' }
            $oldNo = Get-XVal $ent 'south' 2
            if ($null -ne $oldNo -and $oldNo.Length -gt 0) {
                Write-Log ('地块 ' + $h + ' 已是权属线（宗地号 ' + $oldNo + '），跳过')
                $rec.Status = 'SKIP'; $rec.Phase = 'skip'; $rec.ParcelNo = $oldNo
                $summary.Add($rec); continue
            }
            $info = $parcelInfo[$h]
            $pts = $info.Verts; $bb = $info.BBox
            $rec.Verts = $pts.Count
            $rec.Area = [math]::Abs($ent.Area)
            Write-Log ('---- 地块 ' + $idx + '/' + $cands.Count + ' 句柄=' + $h + ' 顶点=' + $pts.Count + ' 面积=' + (N3 $rec.Area) + ' ----')

            $phase = 'pick'
            $cands2 = Get-EdgeCandidates $pts
            $pickX = 0.0; $pickY = 0.0; $pickOk = $false
            $margin = [math]::Max(($bb.MaxX - $bb.MinX) * 0.3, 5.0)
            Zoom-Window $doc ($bb.MinX - $margin) ($bb.MinY - $margin) ($bb.MaxX + $margin) ($bb.MaxY + $margin)
            $tryN = [math]::Min(5, $cands2.Count)
            for ($k = 0; $k -lt $tryN; $k++) {
                $px = $cands2[$k].X; $py = $cands2[$k].Y
                $pickFile = 'E:/AI-Workspace/Logs/_s5_pick.txt'
                $cmd = '(setq *S5-PICKFILE* "' + $pickFile + '") (c:S5PICKAT ' + (N3 $px) + ' ' + (N3 $py) + ') '
                Send-Queued $doc $cmd | Out-Null
                Start-Sleep -Milliseconds 900
                $got = @(Get-Content 'E:\AI-Workspace\Logs\_s5_pick.txt' -ErrorAction SilentlyContinue)
                if ($got.Count -eq 1 -and $got[0].Trim().ToUpper() -eq $h) {
                    $pickX = $px; $pickY = $py; $pickOk = $true; break
                }
            }
            if (-not $pickOk) { throw '拾取校验失败：边中点未能唯一命中目标地块' }
            Write-Log ('拾取点: ' + (N3 $pickX) + ',' + (N3 $pickY) + '（已校验句柄）')

            $phase = 'interior'
            $ip = Get-Interior $pts
            if ($null -eq $ip) { throw '无法计算地块内点' }
            $labelX = $ip.X; $labelY = $ip.Y
            if (-not (Test-InPoly $pts $labelX $labelY)) { throw '注记点不在多边形内' }
            Write-Log ('注记点: ' + (N3 $labelX) + ',' + (N3 $labelY))

            $phase = 'mark'
            Send-Queued $doc '(c:S5MARK) ' | Out-Null
            Start-Sleep -Milliseconds 700
            $beforeSet = New-Object System.Collections.Generic.HashSet[string]
            for ($i = 0; $i -lt $ms.Count; $i++) { $beforeSet.Add(([string]$ms.Item($i).Handle).ToUpper()) | Out-Null }
            $countBefore = $ms.Count

            $phase = 'convert'
            $cmd1 = 'PLTOJZLINE' + "`n" + (N3 $pickX) + ',' + (N3 $pickY) + "`n" + (N3 $labelX) + ',' + (N3 $labelY) + "`n"
            Write-Log ('发送: PLTOJZLINE 选择=' + (N3 $pickX) + ',' + (N3 $pickY) + ' 注记=' + (N3 $labelX) + ',' + (N3 $labelY))
            Send-QueuedAsync $cmd1 | Out-Null
            $res = Wait-Command -doc $doc -pidAcad $pidAcad -countBefore $countBefore -timeoutSec $TimeoutSec -dialogTitle '权属'
            Write-Log ('转换结束: done=' + $res.Done + ' dialog=' + $res.Dialog + ' 实体=' + $res.Count)
            $sp1 = Get-Space $doc 1
            if ($null -eq $sp1) { throw '转换后无法读取模型空间' }
            $ms = $sp1.Space

            $phase = 'verify-parcel'
            $ent2 = $doc.HandleToObject($h)
            if ($null -eq $ent2) { throw '转换后找不到地块对象' }
            $no = Get-XVal $ent2 'south' 2
            if ($null -eq $no -or $no.Length -eq 0) { throw '转换失败：权属线未写入宗地号' }
            $rec.ParcelNo = $no
            Write-Log ('权属线宗地号: ' + $no)

            $phase = 'verify-jzd'
            $newCircles = New-Object System.Collections.Generic.List[object]
            $newTexts = New-Object System.Collections.Generic.List[string]
            for ($i = 0; $i -lt $ms.Count; $i++) {
                $e = $ms.Item($i)
                $eh = ([string]$e.Handle).ToUpper()
                if ($beforeSet.Contains($eh)) { continue }
                if ($e.ObjectName -eq 'AcDbCircle' -and $e.Layer -eq 'JZP') { $newCircles.Add($e) }
                elseif ($e.ObjectName -eq 'AcDbText' -and $e.Layer -eq 'JZP') { $newTexts.Add([string]$e.TextString) }
            }
            $rec.JzdCount = $newCircles.Count
            if ($newCircles.Count -ne $pts.Count) { throw ('界址点数量不符: ' + $newCircles.Count + ' vs 顶点 ' + $pts.Count) }
            $bad = 0
            foreach ($cc in $newCircles) { $z = Get-XVal $cc 'ZDDJH' 1; if ($z -ne ('121311' + $no)) { $bad++ } }
            if ($bad -gt 0) { throw ('有 ' + $bad + ' 个界址点的 ZDDJH 与当前宗地号不一致') }
            $expected = @(); for ($k = 1; $k -le $pts.Count; $k++) { $expected += ('J' + $k) }
            $sorted = @($newTexts | Sort-Object { [int]($_ -replace '[^0-9]', '') })
            if (($sorted -join ',') -ne ($expected -join ',')) { throw ('界址点点号不是 J1..J' + $pts.Count + ' : ' + ($sorted -join ',')) }
            Write-Log ('界址点: ' + $newCircles.Count + ' 个，点号 J1..J' + $pts.Count + '，宗地号校验通过')

            $phase = 'table'
            $tablePtX = $bb.MinX
            $tablePtY = $bb.MaxY + [math]::Max(($bb.MaxY - $bb.MinY) * $GapRatio, 1.0)
            $sp2 = Get-Space $doc 1
            if ($null -eq $sp2) { throw '表格阶段无法读取模型空间' }
            $ms = $sp2.Space
            Send-Queued $doc '(c:S5MARK) ' | Out-Null
            Start-Sleep -Milliseconds 700
            $countBefore2 = [int]$doc.ModelSpace.Count
            $markOk = $true
            $cmd2 = 'JZDZB' + "`n" + (N3 $tablePtX) + ',' + (N3 $tablePtY) + "`n" + "`n" + (N3 $pickX) + ',' + (N3 $pickY) + "`n"
            Write-Log ('发送: JZDZB 表格暂定点=' + (N3 $tablePtX) + ',' + (N3 $tablePtY))
            Send-Queued $doc $cmd2 | Out-Null
            $res2 = Wait-Command -doc $doc -pidAcad $pidAcad -countBefore $countBefore2 -timeoutSec $TimeoutSec
            Write-Log ('坐标表生成结束: done=' + $res2.Done + ' 实体=' + $res2.Count)
            if (-not $res2.Done -or $res2.Count -le $countBefore2) { throw '坐标表未生成' }

            $phase = 'table-move'
            Start-Sleep -Milliseconds 600
            $sp3 = Get-Space $doc ($countBefore2 + 1)
            if ($sp3) { $ms = $sp3.Space }
            $newTab = New-Object System.Collections.Generic.List[object]
            $tableHandles = New-Object System.Collections.Generic.HashSet[string]
            for ($i = 0; $i -lt $ms.Count; $i++) {
                $e = $ms.Item($i)
                if ($e.Layer -ne 'tk') { continue }
                $eh2 = ([string]$e.Handle).ToUpper()
                if ($beforeSet.Contains($eh2)) { continue }
                $tableHandles.Add($eh2) | Out-Null
                $mn = $null; $mx = $null; $e.GetBoundingBox([ref]$mn, [ref]$mx)
                $newTab.Add([pscustomobject]@{ Ent = $e; MinX = $mn[0]; MinY = $mn[1]; MaxX = $mx[0]; MaxY = $mx[1] })
            }
            Write-Log ('表格筛选: 实体总数=' + [int]$ms.Count + ' 转换前集合=' + $beforeSet.Count + ' 新增tk=' + $newTab.Count)
            if ($newTab.Count -eq 0) { throw '未找到生成的表格实体' }
            $tMinX = ($newTab | Measure-Object -Property MinX -Minimum).Minimum
            $tMinY = ($newTab | Measure-Object -Property MinY -Minimum).Minimum
            $tMaxX = ($newTab | Measure-Object -Property MaxX -Maximum).Maximum
            $tMaxY = ($newTab | Measure-Object -Property MaxY -Maximum).Maximum
            $rec.TableEntities = $newTab.Count
            Write-Log ('表格生成后包围盒: (' + (N3 $tMinX) + ',' + (N3 $tMinY) + ')-(' + (N3 $tMaxX) + ',' + (N3 $tMaxY) + ') 实体=' + $newTab.Count)

            $targetTop = $cursorY
            $cmd3 = '(c:S5MOVETOP ' + (N3 $slotX) + ' ' + (N3 $targetTop) + ') '
            Send-Queued $doc $cmd3 | Out-Null
            Start-Sleep -Seconds 2

            $phase = 'table-verify'
            $t2 = New-Object System.Collections.Generic.List[object]
            foreach ($th in $tableHandles) {
                $e = $doc.HandleToObject($th)
                if ($null -eq $e) { continue }
                $mn = $null; $mx = $null; $e.GetBoundingBox([ref]$mn, [ref]$mx)
                if ($null -ne $mn) { $t2.Add([pscustomobject]@{ MinX = $mn[0]; MinY = $mn[1]; MaxX = $mx[0]; MaxY = $mx[1] }) }
            }
            if ($t2.Count -eq 0) { throw '表格实体丢失' }
            $fMinX = ($t2 | Measure-Object -Property MinX -Minimum).Minimum
            $fMinY = ($t2 | Measure-Object -Property MinY -Minimum).Minimum
            $fMaxX = ($t2 | Measure-Object -Property MaxX -Maximum).Maximum
            $fMaxY = ($t2 | Measure-Object -Property MaxY -Maximum).Maximum
            $devX = [math]::Abs($fMinX - $slotX); $devY = [math]::Abs($fMaxY - $targetTop)
            Write-Log ('表格移动后包围盒: (' + (N3 $fMinX) + ',' + (N3 $fMinY) + ')-(' + (N3 $fMaxX) + ',' + (N3 $fMaxY) + ') 偏差 dx=' + (N3 $devX) + ' dy=' + (N3 $devY))
            if ($devX -gt 0.05 -or $devY -gt 0.05) { throw ('表格对齐偏差过大 dx=' + (N3 $devX) + ' dy=' + (N3 $devY)) }

            $cursorY = $fMinY - $gapY
            $rec.Status = 'OK'; $rec.Phase = 'done'
            Write-Log ('地块 ' + $h + ' 完成：宗地号=' + $no + ' 界址点=' + $newCircles.Count + ' 表格实体=' + $newTab.Count)
        }
        catch {
            $rec.Status = 'FAIL'; $rec.Phase = $phase; $rec.Error = $_.Exception.Message
            Write-Log ('地块 ' + $h + ' 失败（阶段 ' + $phase + '）：' + $_.Exception.Message, 'ERROR')
        }
        $summary.Add($rec)
    }

    $okCount = @($summary | Where-Object { $_.Status -eq 'OK' }).Count
    $failCount = @($summary | Where-Object { $_.Status -eq 'FAIL' }).Count
    $skipCount = @($summary | Where-Object { $_.Status -eq 'SKIP' }).Count
    Write-Log ('汇总: 成功=' + $okCount + ' 失败=' + $failCount + ' 跳过=' + $skipCount)

    if ($okCount -gt 0) {
        try { $doc.Save() ; Write-Log ('已保存: ' + $outFull + ' ' + (Get-Item $outFull).Length + ' 字节') }
        catch { Write-Log ('保存失败: ' + $_.Exception.Message, 'ERROR') }
    } else {
        Write-Log '没有成功地块，未保存工作副本' 'WARN'
    }
}
finally {
    if ($doc -and $origVars.Count -gt 0) {
        foreach ($k in $origVars.Keys) {
            try { $doc.SetVariable($k, $origVars[$k]) } catch { }
        }
        Write-Log ('已恢复系统变量: ' + (($origVars.Keys | ForEach-Object { $_ + '=' + $origVars[$_] }) -join '; '))
    }
    $csv = Join-Path (Split-Path -Parent $LogFile) ([IO.Path]::GetFileNameWithoutExtension($OutDwg) + '_V12地块清单.csv')
    if ($summary.Count -gt 0) {
        $summary | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8
        Write-Log ('地块清单: ' + $csv)
    }
    Write-Log ('耗时: ' + [int]((Get-Date) - $t0).TotalSeconds + ' 秒')
    Write-Log '======== STEP5 V1.2 结束 ========'
}
