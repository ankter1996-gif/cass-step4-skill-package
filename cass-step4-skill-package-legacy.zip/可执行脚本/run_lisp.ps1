param(
    [Parameter(Mandatory=$true)][string]$Cmd,
    [string]$WaitFile = '',
    [int]$TimeoutSec = 120,
    [string]$Save = 'no',
    [string]$ExpectPath = '',
    [string]$SaveAs = ''
)

$ErrorActionPreference = 'Stop'

$acad = $null
for ($t = 0; $t -lt 30 -and -not $acad; $t++) {
    try { $acad = [Runtime.InteropServices.Marshal]::GetActiveObject('AutoCAD.Application') }
    catch { Start-Sleep -Seconds 2 }
}
if (-not $acad) { Write-Output 'ATTACH-FAIL'; exit 1 }

$doc = $acad.ActiveDocument
Write-Output ("DOC: " + $doc.FullName)

if ($ExpectPath -ne '') {
    $a = ($doc.FullName -replace '/', '\').ToLower()
    $b = ($ExpectPath -replace '/', '\').ToLower()
    if ($a -ne $b) {
        Write-Output "ABORT: active document is not the expected one"
        Write-Output ("  expected: " + $ExpectPath)
        Write-Output ("  actual  : " + $doc.FullName)
        exit 3
    }
    Write-Output "TARGET-OK"
}

if ($WaitFile -and (Test-Path $WaitFile)) { Remove-Item $WaitFile -Force -ErrorAction SilentlyContinue }

$doc.SendCommand($Cmd)

if ($WaitFile) {
    $sw = [Diagnostics.Stopwatch]::StartNew()
    while ($sw.Elapsed.TotalSeconds -lt $TimeoutSec) {
        Start-Sleep -Milliseconds 400
        if (Test-Path $WaitFile) { Write-Output ("WAIT-OK: " + $WaitFile); break }
    }
    if (-not (Test-Path $WaitFile)) { Write-Output ("WAIT-TIMEOUT: " + $WaitFile); exit 2 }
}

if ($SaveAs -ne '') {
    Start-Sleep -Milliseconds 800
    $doc = $acad.ActiveDocument
    if (Test-Path $SaveAs) { Remove-Item $SaveAs -Force -ErrorAction SilentlyContinue }
    $doc.SaveAs($SaveAs)
    Start-Sleep -Milliseconds 800
    Write-Output ("SAVED-AS: " + $SaveAs + "  " + (Get-Item $SaveAs).Length + " B")
}

if ($Save -eq 'yes') {
    Start-Sleep -Milliseconds 800
    $doc = $acad.ActiveDocument
    $doc.Save()
    Start-Sleep -Milliseconds 800
    Write-Output ("SAVED: " + $doc.FullName + "  " + (Get-Item $doc.FullName).Length + " B")
}

exit 0
