# -*- coding: utf-8 -*-
import csv, collections
src = r"E:\AI-Workspace\Logs\TK_STEP4_A_parcels3.csv"
rows = list(csv.DictReader(open(src, encoding="utf-8-sig")))
A = ("0101","0102","0103","0301","0302","0305","0307")
map_ = {
 "0101":"稻田/211100/gc120","0102":"稻田/211100/gc120","0103":"旱地/211200/gc119",
 "0301":"成林/213100/gc326","0307":"成林/213100/gc326","0302":"大面积竹林/213901/gc246",
 "0305":"大面积灌木林/213201/gc160"}
out = r"E:\AI-Workspace\Output\63\A类21个地块处理明细.csv"
with open(out,"w",encoding="utf-8-sig",newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["序号","边界句柄","地类图层","DLBM","CASS符号/编码/块名","本块符号数","状态"])
    n = 0
    for r in rows:
        code = r["layer"][:4]
        if code not in A: continue
        n += 1
        cnt = int(r["symbols"])
        w.writerow([n, r["handle"], r["layer"], code, map_.get(code,""), cnt,
                    "OK" if cnt > 0 else "异常-无符号"])
print("A parcels:", n)
# 汇总
agg = collections.OrderedDict()
for r in rows:
    code = r["layer"][:4]
    if code not in A: continue
    a = agg.setdefault(code, {"n":0,"sym":0,"zero":0})
    a["n"] += 1; a["sym"] += int(r["symbols"])
    if int(r["symbols"]) == 0: a["zero"] += 1
for k,v in agg.items():
    print(f"  {k} parcels={v['n']} symbols={v['sym']} zero={v['zero']}")
