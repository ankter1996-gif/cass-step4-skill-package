;; TK_STEP4_B_C.lsp -- step4 class B (ANSI31 magenta hatch) + class C (colour / water text)
(vl-load-com)

(setq *S4-LOG* "E:/AI-Workspace/Logs/TK_STEP4.log")
(setq *S4-HSCALE* 30.0)

(defun s4:log (s fh) (write-line s fh) (princ (strcat "\n" s)))

;; leading code of a layer name: digits and upper-case letters only
(defun s4:code (lay / i n ch out stop)
  (setq i 1 n (strlen lay) out "" stop nil)
  (while (and (<= i n) (not stop))
    (setq ch (substr lay i 1))
    (if (or (and (>= (ascii ch) 48) (<= (ascii ch) 57))
            (and (>= (ascii ch) 65) (<= (ascii ch) 90)))
      (setq out (strcat out ch))
      (setq stop T))
    (setq i (1+ i)))
  out)

;; centroid of a closed polyline: average of vertices
(defun s4:centre (e / ed pts p sx sy n bb mn mx)
  (setq ed (entget e) pts '())
  (foreach p ed (if (= 10 (car p)) (setq pts (cons (cdr p) pts))))
  (if pts
    (progn
      (setq sx 0.0 sy 0.0 n 0)
      (foreach p pts (setq sx (+ sx (car p)) sy (+ sy (cadr p)) n (1+ n)))
      (setq sx (/ sx n) sy (/ sy n)))
    (progn
      (setq bb (vl-catch-all-apply 'vla-GetBoundingBox (list (vlax-ename->vla-object e) 'mn 'mx)))
      (if (not (vl-catch-all-error-p bb))
        (progn (setq mn (vlax-safearray->list mn) mx (vlax-safearray->list mx))
               (setq sx (/ (+ (car mn) (car mx)) 2.0) sy (/ (+ (cadr mn) (cadr mx)) 2.0)))
        (setq sx 0.0 sy 0.0))))
  (list sx sy))

(defun c:TKSTEP4 ( / doc ms ss i e ed lay code bb mn mx fh nB nR nW nT fa
                     arr hx txt hgt cde)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setq ms (vla-get-ModelSpace doc))
  (setq fh (open *S4-LOG* "w"))
  (s4:log "=== TK step4  B/C ===" fh)
  (s4:log (strcat "drawing : " (getvar "DWGPREFIX") (getvar "DWGNAME")) fh)
  (s4:log (strcat "hatch   : ANSI31  colour 6  scale " (rtos *S4-HSCALE* 2 1)) fh)

  (setq nB 0 nR 0 nW 0 nT 0)
  (setq fa (ssget "_X" '((0 . "LWPOLYLINE") (410 . "Model"))))

  ;; ---------- class B : ANSI31 magenta hatch ----------
  (setq i 0)
  (while (and fa (< i (sslength fa)))
    (setq e (ssname fa i) ed (entget e) lay (cdr (assoc 8 ed)) code (s4:code lay))
    (if (member code '("0508" "05H1" "0601" "0602" "0701" "0702" "0809"
                       "08H1" "08H2" "08H2A" "09" "1005" "1008" "1109" "1202"))
      (progn
        (setq nB (1+ nB))
        (setq arr (vlax-make-safearray vlax-vbObject '(0 . 0)))
        (vlax-safearray-put-element arr 0 (vlax-ename->vla-object e))
        (setq hx (vla-AddHatch ms 0 "ANSI31" :vlax-true))
        (vla-put-PatternScale hx *S4-HSCALE*)
        (vla-put-Color hx 6)
        (vla-AppendOuterLoop hx arr)
        (vla-Evaluate hx)
        (s4:log (strcat "  B hatch  " lay "  h=" (cdr (assoc 5 ed))) fh)))
    (setq i (1+ i)))

  ;; ---------- class C : colour only ----------
  (setq i 0)
  (while (and fa (< i (sslength fa)))
    (setq e (ssname fa i) ed (entget e) lay (cdr (assoc 8 ed)) code (s4:code lay))
    ;; roads : cyan RGB(0,255,255)
    (if (member code '("1001" "1003" "1004" "1006"))
      (progn
        (setq ed (vl-remove-if '(lambda (p) (member (car p) '(62 420))) (entget e)))
        (entmod (append ed (list (cons 420 65535))))
        (setq nR (1+ nR))
        (s4:log (strcat "  C road   " lay "  h=" (cdr (assoc 5 (entget e)))) fh)))
    ;; water : blue RGB(0,0,255) (+ text)
    (if (member code '("1101" "1102" "1103" "1104" "1104A" "1106" "1107" "1107A"))
      (progn
        (setq ed (vl-remove-if '(lambda (p) (member (car p) '(62 420))) (entget e)))
        (entmod (append ed (list (cons 420 255))))
        (setq nW (1+ nW))
        (setq txt (cond ((= code "1101") "����")
                        ((= code "1102") "����")
                        ((= code "1103") "ˮ��")
                        ((or (= code "1104") (= code "1104A")) "��")
                        (T nil)))
        (if txt
          (progn
            (setq bb (s4:centre e) hgt 2.0)
            (entmake (list '(0 . "TEXT") '(100 . "AcDbEntity") '(100 . "AcDbText")
                           (cons 8 lay) (cons 420 255)
                           (cons 10 (list (car bb) (cadr bb) 0.0))
                           (cons 40 hgt) (cons 1 txt) (cons 72 1) (cons 73 2)
                           (cons 11 (list (car bb) (cadr bb) 0.0))))
            (setq nT (1+ nT))
            (s4:log (strcat "  C water  " lay "  text=" txt " at "
                            (rtos (car bb) 2 2) "," (rtos (cadr bb) 2 2)) fh)))))
    (setq i (1+ i)))

  (s4:log "" fh)
  (s4:log (strcat "SUMMARY B-hatch=" (itoa nB) " road=" (itoa nR)
                  " water=" (itoa nW) " text=" (itoa nT)) fh)
  (s4:log "done" fh)
  (close fh)
  (setq fh (open "E:/AI-Workspace/Logs/_s4_done.txt" "w")) (close fh)
  (princ))
(princ "\nTK_STEP4 loaded.")
(princ)
