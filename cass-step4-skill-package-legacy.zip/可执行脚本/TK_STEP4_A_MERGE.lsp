;; TK_STEP4_A_MERGE.lsp -- merge A-class CASS symbols into the B/C result
;; Each temp drawing is inserted as a block, exploded, and its duplicated
;; boundaries (LWPOLYLINE on layer ZBTZ) are removed; symbol INSERTs stay.
(vl-load-com)

(setq *M-LOG* "E:/AI-Workspace/Logs/TK_STEP4_A_merge.log")

(defun m:log (s fh) (write-line s fh) (princ (strcat "\n" s)))

(defun m:merge1 (path fh / e n0 n1 nins npl)
  (setq n0 (sslength (ssget "_X")))
  (m:log (strcat "  insert " path) fh)
  (command "_.-INSERT" path '(0.0 0.0 0.0) 1.0 1.0 0.0)
  (setq e (entlast))
  (if (and e (= (cdr (assoc 0 (entget e))) "INSERT"))
    (progn
      (command "_.EXPLODE" e)
      (m:log "    exploded" fh))
    (m:log "    WARN: insert failed" fh))
  ;; drop the duplicated boundaries that came with the temp drawing
  (setq npl 0)
  (if (setq ss (ssget "_X" '((0 . "LWPOLYLINE") (8 . "ZBTZ"))))
    (progn (setq npl (sslength ss))
           (command "_.ERASE" ss "")
           (m:log (strcat "    removed dup boundaries: " (itoa npl)) fh)))
  (setq n1 (sslength (ssget "_X")))
  (m:log (strcat "    entities " (itoa n0) " -> " (itoa n1)
                 "  (+" (itoa (- n1 n0)) ")") fh))

(defun c:TKMERGE ( / fh)
  (setq fh (open *M-LOG* "w"))
  (m:log "=== merge A-class symbols ===" fh)
  (m:log (strcat "target : " (getvar "DWGPREFIX") (getvar "DWGNAME")) fh)
  (m:log (strcat "start  : " (itoa (sslength (ssget "_X")))) fh)
  (m:merge1 "E:/AI-Workspace/Output/63/A����ʱ�ɹ�/A01_����_13��.dwg" fh)
  (m:merge1 "E:/AI-Workspace/Output/63/A����ʱ�ɹ�/A02_����_4��.dwg" fh)
  (m:merge1 "E:/AI-Workspace/Output/63/A����ʱ�ɹ�/A03_����_2��.dwg" fh)
  (m:merge1 "E:/AI-Workspace/Output/63/A����ʱ�ɹ�/A04_���������_1��.dwg" fh)
  (m:merge1 "E:/AI-Workspace/Output/63/A����ʱ�ɹ�/A05_�������ľ��_1��.dwg" fh)
  (m:log (strcat "end    : " (itoa (sslength (ssget "_X")))) fh)
  (close fh)
  (setq fh (open "E:/AI-Workspace/Logs/_merge_done.txt" "w")) (close fh)
  (princ))
(princ "\nTKMERGE loaded.")
(princ)
