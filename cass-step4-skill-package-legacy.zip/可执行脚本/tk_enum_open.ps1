param(
    [Parameter(Mandatory=$true)][string]$PathFile,
    [Parameter(Mandatory=$true)][string]$OutFile,
    [string]$DoClose = 'no'
)
$ErrorActionPreference = 'Stop'
$target = [System.IO.File]::ReadAllText($PathFile, [System.Text.Encoding]::UTF8)

$acad = $null
for ($t = 0; $t -lt 40 -and -not $acad; $t++) {
    try { $acad = New-Object -ComObject AutoCAD.Application }
    catch { Start-Sleep -Seconds 3 }
}
if (-not $acad) { Write-Output "cannot start AutoCAD"; exit 4 }
$acad.Visible = $true
Start-Sleep -Seconds 3
$doc = $null
for ($t = 0; $t -lt 20 -and -not $doc; $t++) {
    try { $doc = $acad.Documents.Open($target) }
    catch { Start-Sleep -Seconds 3 }
}
if (-not $doc) { Write-Output "cannot open drawing"; exit 5 }
Start-Sleep -Seconds 3
$ms = $doc.ModelSpace
Write-Output ("opened: " + $doc.Name + "  entities=" + $ms.Count)

$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("IDX`tOBJNAME`tLAYER`tHANDLE`tXMIN`tYMIN`tXMAX`tYMAX`tH`tW`tCLOSED`tVERTS`tCONTENT")

for ($i = 0; $i -lt $ms.Count; $i++) {
    $e = $ms.Item($i)
    $name = ''; $layer = ''; $hd = ''
    try { $name = $e.ObjectName } catch { }
    try { $layer = $e.Layer } catch { }
    try { $hd = $e.Handle } catch { }
    $xmin=''; $ymin=''; $xmax=''; $ymax=''; $hgt=''; $wid=''
    try {
        $mn = $null; $mx = $null
        $e.GetBoundingBox([ref]$mn, [ref]$mx)
        if ($mn -ne $null -and $mx -ne $null) {
            $xmin=[math]::Round($mn[0],3); $ymin=[math]::Round($mn[1],3)
            $xmax=[math]::Round($mx[0],3); $ymax=[math]::Round($mx[1],3)
            $hgt=[math]::Round($mx[1]-$mn[1],3); $wid=[math]::Round($mx[0]-$mn[0],3)
        }
    } catch { }
    $closed=''; $verts=''
    try { if ($name -like 'AcDb*Polyline') { $closed = [int]$e.Closed; $verts = $e.NumberOfVertices } } catch { }
    $txt = ''
    try {
        switch ($name) {
            'AcDbText'  { $txt = $e.TextString }
            'AcDbMText' { $txt = $e.TextString }
            'AcDbBlockReference' {
                $txt = 'BLOCK=' + $e.Name
                if ($e.HasAttributes) {
                    foreach ($a in $e.GetAttributes()) { $txt += ' {@' + $a.TagString + '=' + $a.TextString + '}' }
                }
            }
        }
    } catch { }
    $txt = ($txt -replace "`r?`n", ' ')
    $lines.Add(("{0}`t{1}`t{2}`t{3}`t{4}`t{5}`t{6}`t{7}`t{8}`t{9}`t{10}`t{11}`t{12}" -f $i,$name,$layer,$hd,$xmin,$ymin,$xmax,$ymax,$hgt,$wid,$closed,$verts,$txt))
}
$lines.Add("TOTAL=`t" + $ms.Count)
[System.IO.File]::WriteAllLines($OutFile, $lines, (New-Object System.Text.UTF8Encoding($false)))
Write-Output ("tsv: " + $OutFile)

if ($DoClose -eq 'yes') { $doc.Close($false) }
