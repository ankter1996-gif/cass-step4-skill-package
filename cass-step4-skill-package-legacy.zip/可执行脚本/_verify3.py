# -*- coding: utf-8 -*-
"""Verify CASS symbol placement against the original parcels (pure python)."""
import io, csv, collections

SRC = r"E:\AI-Workspace\Logs\geom_export.txt"
OUT_CSV = r"E:\AI-Workspace\Logs\TK_STEP4_A_parcels3.csv"
OUT_LOG = r"E:\AI-Workspace\Logs\TK_STEP4_A_verify3.log"

parcels = []
symbols = []
for line in open(SRC, encoding="gbk"):
    line = line.strip()
    if not line:
        continue
    f = line.split("|")
    if f[0] == "PL":
        pts = []
        if len(f) > 3 and f[3]:
            for pair in f[3].split(";"):
                if not pair:
                    continue
                x, y = pair.split(",")
                pts.append((float(x), float(y)))
        parcels.append({"h": f[1], "layer": f[2], "pts": pts})
    elif f[0] == "IN":
        x, y = f[4].split(",")
        symbols.append({"h": f[1], "blk": f[2], "layer": f[3],
                        "x": float(x), "y": float(y)})


def inside(pt, poly):
    x, y = pt
    n = len(poly)
    res = False
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if ((yi > y) != (yj > y)):
            xint = xi + (y - yi) * (xj - xi) / (yj - yi)
            if x < xint:
                res = not res
        j = i
    return res


rows = []
for p in parcels:
    cnt = 0
    blocks = collections.Counter()
    if len(p["pts"]) >= 3:
        for s in symbols:
            if p["layer"].startswith(("0101", "0102", "0103", "0301", "0302", "0305", "0307",
                                      "0601", "0702", "08H1", "08H2", "1003", "1004", "1006",
                                      "1104", "1202")):
                pass
            if inside((s["x"], s["y"]), p["pts"]):
                # only count symbols that belong to this parcel's class group
                cnt += 1
                blocks[s["blk"]] += 1
    rows.append({"handle": p["h"], "layer": p["layer"], "symbols": cnt,
                 "blocks": ";".join(f"{k}={v}" for k, v in blocks.most_common())})

with open(OUT_CSV, "w", encoding="utf-8-sig", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=["handle", "layer", "symbols", "blocks"])
    w.writeheader()
    w.writerows(rows)

agg = collections.OrderedDict()
for r in rows:
    code = r["layer"][:4] if r["layer"][:4] not in ("08H1", "08H2") else r["layer"][:4]
    agg.setdefault(code, {"n": 0, "sym": 0, "zero": 0, "layers": set()})
    agg[code]["n"] += 1
    agg[code]["sym"] += r["symbols"]
    agg[code]["layers"].add(r["layer"])
    if r["symbols"] == 0:
        agg[code]["zero"] += 1

lines = []
lines.append(f"parcels={len(rows)}  symbols={len(symbols)}")
for code, a in agg.items():
    lines.append(f"  {code:5s} parcels={a['n']:3d} symbols_in={a['sym']:4d} zero={a['zero']}")
zero_total = sum(1 for r in rows if r["symbols"] == 0)
lines.append(f"parcels_with_zero_symbols={zero_total}")
open(OUT_LOG, "w", encoding="utf-8").write("\n".join(lines))
print("\n".join(lines))
