# -*- coding: utf-8 -*-
"""Extract the vegetation-fill menu mapping (item name -> tian code) from ACAD.cuix."""
import re, json

POP = r"E:\AI-Workspace\Logs\_cuix\PopMenuRoot.cui"
MG = r"E:\AI-Workspace\Logs\_cuix\MenuGroup.cui"

pop = open(POP, encoding="utf-8").read()
mg = open(MG, encoding="utf-8").read()

i = pop.find("植被填充")
seg = pop[i:i + 20000]
items = re.findall(r'<NameRef[^>]*>([^<]+)</NameRef>[\s\S]{0,220}?<MacroRef MenuMacroID="([^"]+)"', seg)

result = {}
for name, mid in items:
    j = mg.find('UID="%s"' % mid)
    if j < 0:
        continue
    chunk = mg[j:j + 700]
    cmd = re.search(r"<Command>([\s\S]*?)</Command>", chunk)
    if not cmd:
        continue
    c = cmd.group(1).strip()
    # macro form: ^C^C^Ptian;211100;0;^P
    m = re.search(r"tian;(\d+);(\d+)", c, re.I)
    code = m.group(1) if m else ""
    result[name.replace(" ", "")] = {"macro": c, "code": code, "line": m.group(2) if m else ""}

print("items:", len(result))
for k, v in result.items():
    print(f"  {k:12s} code={v['code']:8s} macro={v['macro']}")

json.dump(result, open(r"E:\AI-Workspace\Logs\cass_veg_menu.json", "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
