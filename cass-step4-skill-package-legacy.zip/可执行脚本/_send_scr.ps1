param([string]$Scr)
$acad=$null
for($i=0;$i -lt 20 -and -not $acad;$i++){ try{ $acad=[Runtime.InteropServices.Marshal]::GetActiveObject('AutoCAD.Application') }catch{ Start-Sleep -Seconds 2 } }
if(-not $acad){ exit 1 }
$doc=$acad.ActiveDocument
$doc.SendCommand("_.SCRIPT ""$Scr"" " + "`n")
Start-Sleep -Seconds 45
